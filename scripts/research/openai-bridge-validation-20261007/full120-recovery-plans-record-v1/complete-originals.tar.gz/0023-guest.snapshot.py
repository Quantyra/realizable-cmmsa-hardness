import json,os,shutil,stat,urllib.request
from pathlib import Path
home=Path('/home/dfredriksen_quantyra_org');assert Path.home().resolve()==home
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
req=urllib.request.Request('http://metadata.google.internal/computeMetadata/v1/instance/id',headers={'Metadata-Flavor':'Google'})
with opener.open(req,timeout=10) as r:assert r.headers.get('Metadata-Flavor')=='Google' and r.read().decode()=='7237681467779354904'
assert not (home/'full120-exact-real-complex-operators-warning-cleanup-resource02-launch-once.json').exists()
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:name=(p/'comm').read_text().strip()
 except (FileNotFoundError,PermissionError):continue
 assert name not in ('lean','lake','cp','tar'),(str(p),name)
results=[]
for scope in [{'number': 109, 'run': 'cmmsa_a8_output_20261010T110328Z_0d5c26f4'}, {'number': 110, 'run': 'cmmsa_a8_output_20261011T025221Z_7046a7c0'}, {'number': 111, 'run': 'cmmsa_a8_output_20261011T035621Z_498f7ba6'}, {'number': 112, 'run': 'cmmsa_a8_output_20261011T051406Z_3ef6ddc2'}, {'number': 113, 'run': 'cmmsa_a8_output_20261011T060110Z_204d10cd'}, {'number': 114, 'run': 'cmmsa_a8_output_20261011T070000Z_135b1f28'}, {'number': 115, 'run': 'cmmsa_a8_output_20261011T201326Z_31fcd86a'}, {'number': 116, 'run': 'cmmsa_a8_output_20261011T212933Z_f9a386c2'}, {'number': 117, 'run': 'cmmsa_a8_output_20261011T231800Z_f8f19b01'}, {'number': 118, 'run': 'cmmsa_a8_output_20261012T023620Z_8ea3737a'}, {'number': 119, 'run': 'cmmsa_a8_output_20261012T074255Z_4527aeb2'}]:
 root=home/scope['run']/'.lake/packages';groups={}
 for parent,dirs,files in os.walk(root,followlinks=False):
  for name in files:
   p=Path(parent)/name;st=p.lstat();rel=p.relative_to(root);parts=rel.parts
   if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1:continue
   if {'.lake','build','lib','lean'}<=set(parts) and name.endswith(('.olean','.olean.private','.olean.server','.ilean')):kind='lean-large' if st.st_size>=65536 else 'lean-small'
   elif ({'.lake','build','ir'}<=set(parts) and name.endswith(('.c','.c.o.export','.setup.json'))) or ({'.lake','build','lib','lean'}<=set(parts) and name.endswith('.ir')) or rel.as_posix() in ('batteries/.lake/build/bin/runLinter','mathlib/.lake/build/bin/cache'):kind='generated'
   else:continue
   g=groups.setdefault(kind,{'files':0,'allocated_bytes':0});g['files']+=1;g['allocated_bytes']+=st.st_blocks*512
 results.append({'number':scope['number'],'run':scope['run'],'groups':groups})
for scope,result in zip([{'number': 109, 'run': 'cmmsa_a8_output_20261010T110328Z_0d5c26f4'}, {'number': 110, 'run': 'cmmsa_a8_output_20261011T025221Z_7046a7c0'}, {'number': 111, 'run': 'cmmsa_a8_output_20261011T035621Z_498f7ba6'}, {'number': 112, 'run': 'cmmsa_a8_output_20261011T051406Z_3ef6ddc2'}, {'number': 113, 'run': 'cmmsa_a8_output_20261011T060110Z_204d10cd'}, {'number': 114, 'run': 'cmmsa_a8_output_20261011T070000Z_135b1f28'}, {'number': 115, 'run': 'cmmsa_a8_output_20261011T201326Z_31fcd86a'}, {'number': 116, 'run': 'cmmsa_a8_output_20261011T212933Z_f9a386c2'}, {'number': 117, 'run': 'cmmsa_a8_output_20261011T231800Z_f8f19b01'}, {'number': 118, 'run': 'cmmsa_a8_output_20261012T023620Z_8ea3737a'}, {'number': 119, 'run': 'cmmsa_a8_output_20261012T074255Z_4527aeb2'}],results):
 root=home/scope['run']/'.lake/build';groups={}
 for parent,dirs,files in os.walk(root,followlinks=False):
  for name in files:
   p=Path(parent)/name;st=p.lstat();rel=p.relative_to(root);parts=rel.parts
   if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1:continue
   if {'lib','lean'}<=set(parts) and name.endswith(('.olean','.olean.private','.olean.server','.ilean','.olean.hash')):kind='project-lean-objects'
   elif ('ir' in parts and name.endswith(('.c','.c.o.export','.setup.json'))) or ({'lib','lean'}<=set(parts) and name.endswith('.ir')):kind='project-generated-ir'
   else:continue
   g=groups.setdefault(kind,{'files':0,'allocated_bytes':0});g['files']+=1;g['allocated_bytes']+=st.st_blocks*512
 result['project_groups']=groups
print(json.dumps({'scopes':results,'disk_available_bytes':shutil.disk_usage(home).free,'read_only':True,'compiler_invoked':False}))
