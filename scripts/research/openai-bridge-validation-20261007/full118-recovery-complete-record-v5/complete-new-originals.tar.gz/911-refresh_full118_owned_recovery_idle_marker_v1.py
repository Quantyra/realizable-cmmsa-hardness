"""Refresh only the existing owned VM idle marker during bounded local custody."""
import sys,json
from datetime import datetime,timezone
from pathlib import Path
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H))
from full118_builder02_controller import ROOT,VM_ID
from custody_checks import digest
from full114_dedicated_openssh_v2 import Session
from full118_authorized39_custody_v2 import configured_guard
def main():
 configured_guard().documents();assert not (ROOT/'launch-once.json').exists()
 s=json.loads((ROOT/'start-once.json').read_bytes());assert s['vm_id']==VM_ID and s['source_sha256']==digest(H/'start_inspect_full118_owned_capacity_v3.py')
 f=ROOT/'staging-controls'/('owned-recovery-keepalive-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));f.mkdir(exist_ok=False);(f/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
 with Session(f/'transport') as session:
  state=session.state;out=session.ssh('set -e; date +%s | sudo tee /var/lib/quantyra-idle-shutdown/last-active; systemctl is-active quantyra-idle-shutdown.timer')
  r=dict(state=state,output_sha256=digest(out),existing_owned_lifecycle=True,VM_start_performed=False,compiler_invoked=False,other_vm_modified=False)
 (f/'receipt.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(folder=str(f),marker_refreshed=True,compiler_invoked=False)))
if __name__=='__main__':main()
