import PvNP.RealizableHardness.ActualBinaryMatrixHC46A8AveragedTransport

/-!
S3132 composition increment: two-base averaged transport for the existing A8
route. This is an intermediate inequality only; it does not assemble the
all-pair/support/A9 endpoint `a8_output_q_le_actual_predecessor_sum`.

The square remains inside both normalized base means. For each fixed `S0`,
translation in `T` is a bijection, so summing translated energy over both
carriers gives `card ΩS` times the unshifted T sum. That factor is retained
until it cancels the `card ΩS` in the two-base denominator.
-/

namespace PvNP.RealizableHardness.ActualBinaryMatrixHC46A8AveragedAssembly

open PvNP.RealizableHardness.ActualBinaryMatrixHC46A8OutputCoordinateTransport
open scoped BigOperators
open PvNP.RealizableHardness.BinaryMatrixA1Complex
open PvNP.RealizableHardness.ActualBinaryMatrixHC46T2Transfer
open PvNP.RealizableHardness.ActualBinaryMatrixHC46A7Transfer
open PvNP.RealizableHardness.ActualBinaryMatrixHC46A7HybridW6Transport
open PvNP.RealizableHardness.BinaryMatrixA1TypedFourier
open PvNP.RealizableHardness.BinaryMatrixFourier

set_option autoImplicit false
private abbrev F := ZMod 2
private abbrev V (d : Nat) := Fin d → F
private abbrev W (n : Nat) := Fin n → F

/-- Two-base averaged transport for arbitrary complex `g`, using the actual
normalized typed W6 output energy. The squared normalized N-energy is averaged
over T and S0, with the square inside both means. The corrected graph count is
cubed once. -/
theorem a8_two_base_actual_averaged_transport {n d : Nat}
    (Xmat : BinaryMatrix n d)
    (A2 : Submodule F (V d)) (B2 : Submodule F (W n))
    (hA : LinearMap.range Xmat.transpose.toLin' ≤ A2)
    (hB : B2 ≤ LinearMap.ker Xmat.transpose.toLin')
    (g : BinaryMatrix n d → Complex) :
    let X := Xmat.transpose.toLin'
    let R := LinearMap.range X
    let K := LinearMap.ker X
    let A12 := A2.map R.mkQ
    let B12 := B2.comap K.subtype
    let ΩT := V d →ₗ[F] W n
    let ΩS := (V d ⧸ R) →ₗ[F] K
    let Ω := ((V d ⧸ R) ⧸ A12) →ₗ[F] B12
    let P := a7T2ComplementPair X A2 B2
    let shift (S0 : ΩS) := K.subtype.comp (S0.comp R.mkQ)
    (∑ T : ΩT, ∑ S0 : ΩS,
      ((∑ N : Ω, Complex.normSq
        (complexCarrierHybridFilter R K A12 B12
          (actualW6Derivative Xmat T g)
          (S0 + B12.subtype.comp (N.comp A12.mkQ)))) /
        (Fintype.card Ω : Real)) ^ 2) /
        ((Fintype.card ΩT : Real) * (Fintype.card ΩS : Real)) ≤
      (2 : Real) ^ (Xmat.rank *
        ((Module.finrank F A2 - Module.finrank F (LinearMap.range X)) +
          (Module.finrank F (LinearMap.ker X) - Module.finrank F B2))) ^ 3 *
        ∑ p : P,
          (∑ T : ΩT,
            (typedW6OutputEnergy p.1.1 p.1.2
              (t2QuotientRestrict p.1.1 p.1.2 X)
              (filteredCarrierFunction p.1.1 p.1.2 T g)) ^ 2) /
              (Fintype.card ΩT : Real) := by
  classical
  dsimp
  let X := Xmat.transpose.toLin'
  let R := LinearMap.range X
  let K := LinearMap.ker X
  let A12 := A2.map R.mkQ
  let B12 := B2.comap K.subtype
  let ΩT := V d →ₗ[F] W n
  let ΩS := (V d ⧸ R) →ₗ[F] K
  let Ω := ((V d ⧸ R) ⧸ A12) →ₗ[F] B12
  let P := a7T2ComplementPair X A2 B2
  let shift : ΩS → ΩT := fun S0 => K.subtype.comp (S0.comp R.mkQ)
  let energy : P → ΩT → Real := fun p T =>
    typedW6OutputEnergy p.1.1 p.1.2 (t2QuotientRestrict p.1.1 p.1.2 X)
      (filteredCarrierFunction p.1.1 p.1.2 T g)
  let cubic : Real := (Fintype.card P : Real) ^ 3
  let graph : Real := (2 : Real) ^
    (Xmat.rank * ((Module.finrank F A2 - Module.finrank F (LinearMap.range X)) +
      (Module.finrank F (LinearMap.ker X) - Module.finrank F B2)))
  letI : Nonempty Ω := ⟨0⟩
  letI : Nonempty ΩS := ⟨0⟩
  have hpoint : ∀ T : ΩT, ∀ S0 : ΩS,
      ((∑ N : Ω, Complex.normSq
        (complexCarrierHybridFilter R K A12 B12
          (actualW6Derivative Xmat T g)
          (S0 + B12.subtype.comp (N.comp A12.mkQ)))) /
        (Fintype.card Ω : Real)) ^ 2 ≤
      cubic * ∑ p : P, (energy p (T + shift S0)) ^ 2 := by
    intro T S0
    have h := PvNP.RealizableHardness.ActualBinaryMatrixHC46A8AveragedTransport.a8_fixed_base_actual_energy_cube
      Xmat A2 B2 hA hB T g S0
    simpa [X, R, K, A12, B12, Ω, P, cubic, energy, shift] using h
  have hsum :
      (∑ T : ΩT, ∑ S0 : ΩS,
        ((∑ N : Ω, Complex.normSq
          (complexCarrierHybridFilter R K A12 B12
            (actualW6Derivative Xmat T g)
            (S0 + B12.subtype.comp (N.comp A12.mkQ)))) /
          (Fintype.card Ω : Real)) ^ 2) ≤
      cubic * ((Fintype.card ΩS : Real) *
        ∑ p : P, ∑ T : ΩT, (energy p T) ^ 2) := by
    calc
      _ ≤ ∑ T : ΩT, ∑ S0 : ΩS,
          cubic * ∑ p : P, (energy p (T + shift S0)) ^ 2 := by
        apply Finset.sum_le_sum
        intro T _
        apply Finset.sum_le_sum
        intro S0 _
        exact hpoint T S0
      _ = cubic * ∑ T : ΩT, ∑ S0 : ΩS, ∑ p : P,
          (energy p (T + shift S0)) ^ 2 := by
        simp [Finset.mul_sum]
      _ = cubic * ((Fintype.card ΩS : Real) *
          ∑ p : P, ∑ T : ΩT, (energy p T) ^ 2) := by
        congr 1
        calc
          (∑ T : ΩT, ∑ S0 : ΩS, ∑ p : P,
              (energy p (T + shift S0)) ^ 2) =
            ∑ p : P, ∑ S0 : ΩS, ∑ T : ΩT,
              (energy p (T + shift S0)) ^ 2 := by
                simp_rw [Finset.sum_comm (s := (Finset.univ : Finset P))]
          _ = ∑ p : P, ∑ S0 : ΩS, ∑ T : ΩT,
                (energy p T) ^ 2 := by
              apply Finset.sum_congr rfl
              intro p _
              apply Finset.sum_congr rfl
              intro S0 _
              have hshift : (∑ T : ΩT, (energy p (T + shift S0)) ^ 2) =
                  ∑ T : ΩT, (energy p T) ^ 2 := by
                exact Equiv.sum_comp (Equiv.addRight (shift S0))
                  (fun T => (energy p T) ^ 2)
              exact hshift
          _ = (Fintype.card ΩS : Real) *
                ∑ p : P, ∑ T : ΩT, (energy p T) ^ 2 := by
              simp [Finset.sum_mul]
  have hcard := a7_t2_complement_card_le Xmat A2 B2 hA hB
  have hcardR : (Fintype.card P : Real) ≤ graph := by
    dsimp [P, graph]
    exact_mod_cast hcard
  have hnonneg : 0 ≤ ∑ p : P, ∑ T : ΩT, (energy p T) ^ 2 := by
    apply Finset.sum_nonneg
    intro p _
    apply Finset.sum_nonneg
    intro T _
    exact sq_nonneg _
  have hcubic : cubic ≤ graph ^ 3 := by
    dsimp [cubic]
    exact pow_le_pow_left₀ (by positivity) hcardR
  have hscaled := mul_le_mul_of_nonneg_right hcubic hnonneg
  have hden : 0 < (Fintype.card ΩT : Real) * (Fintype.card ΩS : Real) := by
    positivity
  have hnormalized :
      (∑ T : ΩT, ∑ S0 : ΩS,
        ((∑ N : Ω, Complex.normSq
          (complexCarrierHybridFilter R K A12 B12
            (actualW6Derivative Xmat T g)
            (S0 + B12.subtype.comp (N.comp A12.mkQ)))) /
          (Fintype.card Ω : Real)) ^ 2) /
          ((Fintype.card ΩT : Real) * (Fintype.card ΩS : Real)) ≤
      cubic * ((Fintype.card ΩS : Real) *
        ∑ p : P, ∑ T : ΩT, (energy p T) ^ 2) /
          ((Fintype.card ΩT : Real) * (Fintype.card ΩS : Real)) := by
    exact div_le_div_of_nonneg_right hsum (le_of_lt hden)
  have hcardS : 0 < (Fintype.card ΩS : Real) := by positivity
  have hcardT : 0 < (Fintype.card ΩT : Real) := by positivity
  calc
    _ ≤ cubic * ((Fintype.card ΩS : Real) *
        ∑ p : P, ∑ T : ΩT, (energy p T) ^ 2) /
          ((Fintype.card ΩT : Real) * (Fintype.card ΩS : Real)) := hnormalized
    _ ≤ graph ^ 3 * ((Fintype.card ΩS : Real) *
        ∑ p : P, ∑ T : ΩT, (energy p T) ^ 2) /
          ((Fintype.card ΩT : Real) * (Fintype.card ΩS : Real)) := by
      apply div_le_div_of_nonneg_right _ (le_of_lt hden)
      simpa only [mul_assoc, mul_comm, mul_left_comm] using
        (mul_le_mul_of_nonneg_right hscaled
          (show 0 ≤ (Fintype.card ΩS : Real) by positivity))
    _ = graph ^ 3 * ∑ p : P,
        (∑ T : ΩT, (energy p T) ^ 2) / (Fintype.card ΩT : Real) := by
      rw [Finset.sum_div]
      field_simp [ne_of_gt hcardT, ne_of_gt hcardS]
      <;> ring

end PvNP.RealizableHardness.ActualBinaryMatrixHC46A8AveragedAssembly
