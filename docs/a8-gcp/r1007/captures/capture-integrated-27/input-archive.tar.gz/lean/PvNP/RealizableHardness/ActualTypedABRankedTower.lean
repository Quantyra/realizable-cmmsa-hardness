import PvNP.RealizableHardness.ActualTypedABMixedTower
import PvNP.RealizableHardness.BinaryMatrixTypedA14Line
import PvNP.RealizableHardness.BinaryMatrixTypedA14Reduced
import PvNP.RealizableHardness.BinaryMatrixTypedA14Hyperplane
import PvNP.RealizableHardness.BinaryMatrixTypedA14HyperplaneReduced
import PvNP.RealizableHardness.BinaryMatrixTypedA15Transport

namespace PvNP.RealizableHardness.ActualTypedABRankedTower

open ActualTypedABMixedTower
open BinaryMatrixA1NestedCarrier
open BinaryMatrixTypedA15ReducedGlobal
open BinaryMatrixTypedA15HyperplaneReducedGlobal
open BinaryMatrixTypedA15Transport
open BinaryMatrixTypedA14FixedBase
open BinaryMatrixTypedA14HyperplaneFixedBase
open BinaryMatrixTypedA14Line
open BinaryMatrixTypedA14Reduced
open BinaryMatrixTypedA14Hyperplane
open BinaryMatrixTypedA14HyperplaneReduced

noncomputable section
set_option autoImplicit false

private abbrev F := ZMod 2
private abbrev V (d : Nat) := Fin d → F
private abbrev W (n : Nat) := Fin n → F

/-- An A15 tower with an explicit residual rank. A node with `k+1` steps
uses the selected operator at rank `r+k`; after all steps the terminal
carrier retains the rank-r globalness bound. This is the source-shaped form
needed when derivative order is smaller than the input degree. It does not
assert that the entire terminal signal is homogeneous of rank r. -/
inductive ActualTypedABRankedTower {n d : Nat} :
    (A : Submodule F (V d)) → (B : Submodule F (W n)) →
    (((V d ⧸ A) →ₗ[F] B) → Complex) → Nat → Nat → Type 1
  | done {A : Submodule F (V d)} {B : Submodule F (W n)}
      (f : ((V d ⧸ A) →ₗ[F] B) → Complex) (r : Nat) :
      ActualTypedABRankedTower A B f r 0
  | line {A : Submodule F (V d)} {B : Submodule F (W n)}
      {A' : Submodule F (V d)}
      (hA : A ≤ A')
      (hL : Module.finrank F (A'.map A.mkQ) = 1)
      {r k : Nat} (T : (V d ⧸ A) →ₗ[F] B)
      (f : ((V d ⧸ A) →ₗ[F] B) → Complex)
      (tail : ActualTypedABRankedTower A' B
        (fun M => typedLineReducedWitness (k := r + k)
          B (A'.map A.mkQ) hL T f
          (M.comp (nestedDomainEquiv A A' hA).toLinearMap)) r k) :
      ActualTypedABRankedTower A B f r (k + 1)
  | hyperplane {A : Submodule F (V d)} {B : Submodule F (W n)}
      {H : Submodule F B}
      (hH : Module.finrank F (B ⧸ H) = 1)
      {r k : Nat} (T : (V d ⧸ A) →ₗ[F] B)
      (f : ((V d ⧸ A) →ₗ[F] B) → Complex)
      (tail : ActualTypedABRankedTower A (H.map B.subtype)
        (fun N => typedHyperplaneReducedWitness (k := r + k) B H hH T f
          ((Submodule.equivMapOfInjective B.subtype B.injective_subtype H).symm.toLinearMap.comp N)) r k) :
      ActualTypedABRankedTower A B f r (k + 1)

structure RankedTerminalData (n d : Nat) where
  Aend : Submodule F (V d)
  Bend : Submodule F (W n)
  fend : ((V d ⧸ Aend) →ₗ[F] Bend) → Complex

def rankedTerminalData {n d : Nat} {r k : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    {f : ((V d ⧸ A) →ₗ[F] B) → Complex} :
    (tower : ActualTypedABRankedTower A B f r k) → RankedTerminalData n d
  | .done f _ => ⟨A, B, f⟩
  | .line _ _ _ _ tail => rankedTerminalData tail
  | .hyperplane _ _ _ tail => rankedTerminalData tail

/-- The product of the exact A15 losses for ranks `r+1` through `r+k`.
The terminal rank `r` is retained and is not charged as a derivative step. -/
def rankedA15Loss (r : Nat) : Nat → Real
  | 0 => 1
  | k + 1 => (4 * (2 : Real) ^ (4 * (r + k + 1))) * rankedA15Loss r k

theorem rankedA15Loss_nonneg (r k : Nat) : 0 ≤ rankedA15Loss r k := by
  induction k with
  | zero => simp [rankedA15Loss]
  | succ k ih =>
      simp only [rankedA15Loss]
      positivity

theorem rankedA15Loss_eq_pow (r k : Nat) :
    rankedA15Loss r k =
      (2 : Real) ^ (4 * r * k + 2 * k ^ 2 + 4 * k) := by
  induction k with
  | zero => simp [rankedA15Loss]
  | succ k ih =>
      have hstep : (4 : Real) * (2 : Real) ^ (4 * (r + k + 1)) =
          (2 : Real) ^ (4 * (r + k + 1) + 2) := by
        calc
          (4 : Real) * (2 : Real) ^ (4 * (r + k + 1)) =
              (2 : Real) ^ 2 * (2 : Real) ^ (4 * (r + k + 1)) := by norm_num
          _ = (2 : Real) ^ (2 + 4 * (r + k + 1)) := by rw [← pow_add]
          _ = (2 : Real) ^ (4 * (r + k + 1) + 2) := by congr 1 <;> omega
      have hexp :
          4 * r * (k + 1) + 2 * (k + 1) ^ 2 + 4 * (k + 1) =
            (4 * r * k + 2 * k ^ 2 + 4 * k) +
              (4 * (r + k + 1) + 2) := by ring
      rw [rankedA15Loss, ih, hstep, ← pow_add]
      congr 1
      omega

/-- If the highest selected rank is at most D, the accumulated actual A15
loss for one terminal level is bounded by `2^(10 D^2)`. The extra factor
for summing the at most D+1 orthogonal levels belongs to the subsequent
Parseval step, not this per-level estimate. -/
theorem rankedA15Loss_le_degree (r k D : Nat) (hlevel : r + k ≤ D) :
    rankedA15Loss r k ≤ (2 : Real) ^ (10 * D ^ 2) := by
  rw [rankedA15Loss_eq_pow]
  have hr : r ≤ D := Nat.le_trans (Nat.le_add_right r k) hlevel
  have hk : k ≤ D := Nat.le_trans (Nat.le_add_left k r) hlevel
  have hDsq : D ≤ D ^ 2 := by
    by_cases hD : D = 0
    · simp [hD]
    · have hDpos : 1 ≤ D := Nat.one_le_iff_ne_zero.mpr hD
      nlinarith [Nat.mul_le_mul_left D hDpos]
  have hrk : r * k ≤ D ^ 2 := by
    calc
      r * k ≤ D * D := Nat.mul_le_mul hr hk
      _ = D ^ 2 := by simp [pow_two]
  have hk2 : k ^ 2 ≤ D ^ 2 := Nat.pow_le_pow_left hk 2
  have hexp : 4 * r * k + 2 * k ^ 2 + 4 * k ≤ 10 * D ^ 2 := by
    nlinarith
  exact pow_le_pow_right₀ (by norm_num : (1 : Real) ≤ 2) hexp

/-- Repeated A15 transitions preserve the genuine residual level `r` and
bound its terminal typed globalness from the original function's bound
through `r+k`. No projected-globalness premise is introduced. -/
theorem ranked_tower_terminal_global {n d : Nat} {r k : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    {f : ((V d ⧸ A) →ₗ[F] B) → Complex}
    (tower : ActualTypedABRankedTower A B f r k) :
    ∀ eps : Real, 0 ≤ eps → UpToTypedNormSqGlobal A B (r + k) eps f →
      UpToTypedNormSqGlobal (rankedTerminalData tower).Aend
        (rankedTerminalData tower).Bend r
        (rankedA15Loss r k * eps) (rankedTerminalData tower).fend := by
  induction tower with
  | @done A B f r =>
      intro eps heps hglobal
      simpa [rankedTerminalData, rankedA15Loss] using hglobal
  | @line A B A' hA hL r k T f tail ih =>
      intro eps heps hglobal
      have hglobal' : UpToTypedNormSqGlobal A B ((r + k) + 1) eps f := by
        simpa [Nat.add_assoc] using hglobal
      have hred := adapted_line_oneStep_A15_global (k := r + k)
        A A' B hA hL T f heps hglobal'
      have hflat := reduced_global_to_flat_adapted
        A A' B hA
        (typedLineReducedWitness (k := r + k) B (A'.map A.mkQ) hL T f)
        hred
      have heps' : 0 ≤
          (4 * (2 : Real) ^ (4 * (r + k + 1))) * eps := by positivity
      have htail := ih ((4 * (2 : Real) ^ (4 * (r + k + 1))) * eps)
        heps' hflat
      have hscale : rankedA15Loss r k *
          ((4 * (2 : Real) ^ (4 * (r + k + 1))) * eps) =
          rankedA15Loss r (k + 1) * eps := by
        simp [rankedA15Loss, mul_assoc, mul_left_comm, mul_comm]
      simpa [rankedTerminalData] using hscale ▸ htail

  | @hyperplane A B H hH r k T f tail ih =>
      intro eps heps hglobal
      have hglobal' : UpToTypedNormSqGlobal A B ((r + k) + 1) eps f := by
        simpa [Nat.add_assoc] using hglobal
      have hred := adapted_hyperplane_oneStep_A15_global (k := r + k)
        A B H hH T f heps hglobal'
      have hflat := hyperplane_reduced_global_to_flat_adapted
        A B H
        (typedHyperplaneReducedWitness (k := r + k) B H hH T f)
        hred
      have heps' : 0 ≤
          (4 * (2 : Real) ^ (4 * (r + k + 1))) * eps := by positivity
      have htail := ih ((4 * (2 : Real) ^ (4 * (r + k + 1))) * eps)
        heps' hflat
      have hscale : rankedA15Loss r k *
          ((4 * (2 : Real) ^ (4 * (r + k + 1))) * eps) =
          rankedA15Loss r (k + 1) * eps := by
        simp [rankedA15Loss, mul_assoc, mul_left_comm, mul_comm]
      simpa [rankedTerminalData] using hscale ▸ htail

/-- The residual-rank globalness conclusion gives the actual terminal
whole-carrier energy bound, with the per-level `2^(10 D^2)` loss. This is
the individual-level estimate used before the Parseval sum over levels. -/
theorem ranked_tower_terminal_energy {n d : Nat} {r k D : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    {f : ((V d ⧸ A) →ₗ[F] B) → Complex}
    (tower : ActualTypedABRankedTower A B f r k)
    (hlevel : r + k ≤ D) :
    ∀ eps : Real, 0 ≤ eps → UpToTypedNormSqGlobal A B (r + k) eps f →
      (∑ M : ((V d ⧸ (rankedTerminalData tower).Aend) →ₗ[F]
          (rankedTerminalData tower).Bend),
          Complex.normSq ((rankedTerminalData tower).fend M)) /
          Fintype.card ((V d ⧸ (rankedTerminalData tower).Aend) →ₗ[F]
            (rankedTerminalData tower).Bend) ≤
        (2 : Real) ^ (10 * D ^ 2) * eps := by
  intro eps heps hglobal
  have hterminal := ranked_tower_terminal_global tower eps heps hglobal
  have hzero : UpToTypedNormSqGlobal (rankedTerminalData tower).Aend
      (rankedTerminalData tower).Bend 0
      (rankedA15Loss r k * eps) (rankedTerminalData tower).fend := by
    intro Q hQ
    exact hterminal Q (Nat.le_trans hQ (Nat.zero_le r))
  have henergy := adapted_terminal_energy_of_global hzero
  have hloss := rankedA15Loss_le_degree r k D hlevel
  calc
    (∑ M : ((V d ⧸ (rankedTerminalData tower).Aend) →ₗ[F]
        (rankedTerminalData tower).Bend),
        Complex.normSq ((rankedTerminalData tower).fend M)) /
        Fintype.card ((V d ⧸ (rankedTerminalData tower).Aend) →ₗ[F]
          (rankedTerminalData tower).Bend) ≤ rankedA15Loss r k * eps := henergy
    _ ≤ (2 : Real) ^ (10 * D ^ 2) * eps :=
      mul_le_mul_of_nonneg_right hloss heps

/-- At every node of a residual-rank tower, the actual reduced witness
obeys the manuscript's A14 selected-filter equation at rank `r+k`, and the
same property holds recursively for the stored child. -/
def HasRankedA14Semantics {n d : Nat} {r k : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    {f : ((V d ⧸ A) →ₗ[F] B) → Complex} :
    ActualTypedABRankedTower A B f r k → Prop
  | .done _ _ => True
  | @ActualTypedABRankedTower.line n d A B A' hA hL r k T f tail =>
      (∀ N : ((V d ⧸ A) ⧸ A'.map A.mkQ) →ₗ[F] B,
        reducedComplexRankProjection B (A'.map A.mkQ) (r + k)
          (typedLineReducedWitness (k := r + k) B
            (A'.map A.mkQ) hL T f) N =
        typedComplexLineFilter B (A'.map A.mkQ) hL
          (typedComplexRankProjection A B (r + k + 1) f)
          (T + N.comp (A'.map A.mkQ).mkQ)) ∧
        HasRankedA14Semantics tail
  | @ActualTypedABRankedTower.hyperplane n d A B H hH r k T f tail =>
      (∀ N : (V d ⧸ A) →ₗ[F] H,
        hyperplaneReducedComplexRankProjection B H hH (r + k)
          (typedHyperplaneReducedWitness (k := r + k) B H hH T f) N =
        typedComplexHyperplaneFilter B H hH
          (typedComplexRankProjection A B (r + k + 1) f)
          (T + H.subtype.comp N)) ∧
        HasRankedA14Semantics tail

theorem ranked_tower_has_A14_semantics {n d : Nat} {r k : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    {f : ((V d ⧸ A) →ₗ[F] B) → Complex}
    (tower : ActualTypedABRankedTower A B f r k) :
    HasRankedA14Semantics tower := by
  induction tower with
  | done f r => trivial
  | @line A B A' hA hL r k T f tail ih =>
      constructor
      · intro N
        exact typed_A14_fixedLine A B (A'.map A.mkQ) hL T f N
      · exact ih
  | @hyperplane A B H hH r k T f tail ih =>
      constructor
      · intro N
        exact typed_A14_fixedHyperplane A B H hH T f N
      · exact ih

end
end PvNP.RealizableHardness.ActualTypedABRankedTower
