import PvNP.RealizableHardness.ActualBinaryMatrixHC46DR6Incidence
import PvNP.RealizableHardness.ActualBinaryMatrixHC46A7HybridW6Transport

/-! T1 exact-transfer structures on the actual finite F2 carriers.

The index triple is represented by C <= A, the quotient subspace H/B <= W/B,
and the manuscript isomorphism H/B ~= A/C.  The actual ambient H is recovered
as the preimage of H/B under W -> W/B.  This representation keeps the
quotient carriers explicit; it does not identify the quotient isomorphism,
its pullback H -> V/C, and the original map q_C Y|H.
-/

namespace PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer

open scoped BigOperators

set_option autoImplicit false
noncomputable section
attribute [local instance] Classical.propDecidable

private abbrev F := ZMod 2
private abbrev V (d : Nat) := Fin d -> F
private abbrev W (n : Nat) := Fin n -> F

/-- A T1 index triple. `K` is the actual quotient subspace H/B in W/B;
`Xbar` has the manuscript direction H/B ~= A/C. -/
structure T1IndexTriple {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n)) where
  C : Submodule F A
  K : Submodule F (W n ⧸ B)
  Xbar : K ≃ₗ[F] (A ⧸ C)

/-- Encode the triple by theta : A -> W/B, with the quotient map first,
then Xbar inverse, then the inclusion H/B -> W/B. -/
def t1TripleToMap {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) : A →ₗ[F] (W n ⧸ B) :=
  t.K.subtype.comp (t.Xbar.symm.toLinearMap.comp t.C.mkQ)

/-- Build the quotient triple associated to theta using its kernel and range.
C is the kernel subspace inside A; its ambient image in V is induced by A's
subtype. K is im(theta)=H/B. -/
def t1MapToTriple {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (theta : A →ₗ[F] (W n ⧸ B)) : T1IndexTriple A B where
  C := LinearMap.ker theta
  K := LinearMap.range theta
  Xbar := theta.quotKerEquivRange.symm

/-- The triple-to-map-to-triple direction recovers theta on every vector. -/
theorem t1TripleToMap_mapToTriple {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (theta : A →ₗ[F] (W n ⧸ B)) :
    t1TripleToMap (t1MapToTriple theta) = theta := by
  classical
  ext a
  simp [t1TripleToMap, t1MapToTriple,
    LinearMap.quotKerEquivRange_apply_mk]

/-- Recover the actual ambient H from its quotient subspace K=H/B. -/
def t1AmbientH {n : Nat} {B : Submodule F (W n)}
    (K : Submodule F (W n ⧸ B)) : Submodule F (W n) :=
  K.comap (Submodule.mkQ B)

/-- The quotient map sends the recovered H onto the original quotient
subspace K. -/
theorem t1AmbientH_quotientRange {n : Nat}
    (B : Submodule F (W n)) (K : Submodule F (W n ⧸ B)) :
    LinearMap.range
      ((Submodule.mkQ B).comp (t1AmbientH K).subtype) = K := by
  ext x
  constructor
  · rintro ⟨w, rfl⟩
    exact w.2
  · intro hx
    obtain ⟨w, hw⟩ := (Submodule.mkQ B).surjective x
    have hwmem : w ∈ t1AmbientH K := by
      change Submodule.mkQ B w ∈ K
      rw [hw]
      exact hx
    exact ⟨⟨w, hwmem⟩, hw⟩

/-- The recovered ambient H contains B, including when K is zero. -/
theorem t1AmbientH_containsB {n : Nat}
    (B : Submodule F (W n)) (K : Submodule F (W n ⧸ B)) :
    B ≤ t1AmbientH K := by
  intro b hb
  change Submodule.mkQ B b ∈ K
  simp

/-- Quotienting the recovered H by its copy of B gives exactly K. -/
noncomputable def t1AmbientHQuotientEquiv {n : Nat}
    (B : Submodule F (W n)) (K : Submodule F (W n ⧸ B)) :
    (t1AmbientH K ⧸ B.comap (t1AmbientH K).subtype) ≃ₗ[F] K := by
  let H := t1AmbientH K
  let qH : H →ₗ[F] (W n ⧸ B) := (Submodule.mkQ B).comp H.subtype
  have hker : LinearMap.ker qH = B.comap H.subtype := by
    ext h
    simp [qH, H, t1AmbientH]
  have hrange : LinearMap.range qH = K := by
    simpa [qH, H] using t1AmbientH_quotientRange B K
  let e0 := qH.quotKerEquivRange
  simpa [hker] using e0.trans (LinearEquiv.ofEq _ _ hrange)

end PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer
