import PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer

open PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer

#check T1IndexTriple
#check t1TripleToMap
#check t1MapToTriple
#check t1TripleToMap_mapToTriple
#check t1AmbientH
#check t1AmbientH_quotientRange
#check t1AmbientH_containsB
#check t1AmbientHQuotientEquiv

#print axioms t1TripleToMap_mapToTriple
#print axioms t1AmbientH_quotientRange
#print axioms t1AmbientH_containsB
#print axioms t1AmbientHQuotientEquiv
