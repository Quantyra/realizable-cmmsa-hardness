import PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer

open PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer

#check T1IndexTriple
#check t1TripleToMap
#check t1MapToTriple
#check t1TripleToMap_mapToTriple
#check t1TripleToMap_ker
#check t1TripleToMap_range
#check t1MapToTriple_CK_roundTrip
#check t1TripleToMap_injective
#check t1TripleEquiv
#check t1Triple_card
#check t1TripleToMap_ker
#check t1TripleToMap_range
#check t1MapToTriple_CK_roundTrip
#check t1TripleToMap_injective
#check t1TripleEquiv
#check t1Triple_card
#check t1AmbientH
#check t1AmbientH_quotientRange
#check t1AmbientH_of_quotientRange
#check t1AmbientH_containsB
#check t1AmbientHQuotientEquiv
#check t1AmbientC
#check t1AmbientC_le_A
#check t1AQuotientToAmbient
#check t1PullbackMap
#check t1OriginalRestriction
#check t1RankPrecedes
#check t1ActiveTriple
#check t1SelectedTheta
#check t1SelectedTheta_on_preimage
#check t1SelectedTriple
#check t1SelectedTriple_toMap
#check t1SelectedTheta_ker
#check t1SelectedPreimage
#check t1SelectedTheta_range
#check t1SelectedTriple_ambientH
#check t1SelectedTriple_hybridSelected
#check t1SelectedTriple_unique

#print axioms t1TripleToMap_mapToTriple
#print axioms t1TripleToMap_ker
#print axioms t1TripleToMap_range
#print axioms t1MapToTriple_CK_roundTrip
#print axioms t1TripleToMap_injective
#print axioms t1Triple_card
#print axioms t1TripleToMap_ker
#print axioms t1TripleToMap_range
#print axioms t1MapToTriple_CK_roundTrip
#print axioms t1TripleToMap_injective
#print axioms t1Triple_card
#print axioms t1AmbientH_quotientRange
#print axioms t1AmbientH_of_quotientRange
#print axioms t1AmbientH_containsB
#print axioms t1AmbientHQuotientEquiv
#print axioms t1AmbientC_le_A
#print axioms t1SelectedTheta_on_preimage
#print axioms t1SelectedTriple_toMap
#print axioms t1SelectedTheta_ker
#print axioms t1SelectedTheta_range
#print axioms t1SelectedTriple_ambientH
#print axioms t1SelectedTriple_hybridSelected
#print axioms t1SelectedTriple_unique
