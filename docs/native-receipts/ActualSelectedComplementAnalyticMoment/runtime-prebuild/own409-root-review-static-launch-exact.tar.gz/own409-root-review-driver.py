import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
PACKET = BASE / 'own409-root-native-three-lens'
ATTEMPT = BASE / 'local-native-own409/attempt-409-A7T1Transfer'
PLANNING = Path('C:/Users/Dan/Desktop/Projects/IGH/Quantyra-Planning')
ROLES = ['proof-adversarial', 'complexity-theory', 'non-claims-boundary']

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write_json(p, value):
    Path(p).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

if sys.argv[1] == 'prepare':
    PACKET.mkdir(exist_ok=False)
    expected = {
        'stage-0.lean.snapshot': '304542f3713cd4335f479b11265f78de94afd11d0a2350348772facba426e50b',
        'stage-1.lean.snapshot': '741731fc2ac3438e01cab5494fa611cfc3ab2c4ea6fa4f4cb0ae406347e2f700',
        'stage-1.stdout': 'e31cc7b2f0631afa0024c2952a59951826bec4b09ed0d28c975e7c2db10eaa94',
    }
    for name, identity in expected.items():
        if sha(ATTEMPT / name) != identity:
            raise RuntimeError('immutable identity mismatch: ' + name)
    terminal = json.loads((ATTEMPT / 'terminal.json').read_bytes())
    if terminal['aggregate_exit'] != 0:
        raise RuntimeError('review requires authoritative green')
    index = {str(ATTEMPT / name): {'sha256': sha(ATTEMPT / name), 'size': (ATTEMPT / name).stat().st_size}
             for name in ['stage-0.lean.snapshot', 'stage-1.lean.snapshot', 'stage-0.stdout',
                          'stage-0.stderr', 'stage-1.stdout', 'stage-1.stderr', 'stages.json',
                          'terminal.json', 'reused-input-identities.json']}
    write_json(PACKET / 'immutable-input-index.json', index)
    common = f'''Destination repository: {ROOT}
Planning repository: {PLANNING}
Role: ROLE-reviewer. Model: gpt-6-astra, xhigh. Independent top-level Codex CLI invocation.
Permissions: READ ONLY. No edits, compiler/build/check invocations, Git mutations, network, nested delegation, cloud changes, or cleanup. Do not interrupt live author/compiler work. Sol owns all compiler and Git operations, Luna authors.
Required context: destination AGENTS.md if present; planning docs/protocol.md, docs/local-codex-workflow-protocol.md, docs/formal-three-lens-closeout-protocol.md; active formal story stories/S3126-realizable-hardness-formal-proof-and-paper.md. Bound current review to the immutable own409 declarations, not mutable successor source.
Immutable input index: {PACKET / 'immutable-input-index.json'}
Main exact source: {ATTEMPT / 'stage-0.lean.snapshot'}
Checks exact source: {ATTEMPT / 'stage-1.lean.snapshot'}
Complete terminal evidence: {ATTEMPT / 'stages.json'}, terminal.json, stage-0.stdout/stderr, stage-1.stdout/stderr.
Complete exact green archive: {BASE / 'own409-complete-green-exact.tar.gz'} (SHA256 1007fa18fa3361aedd7cc54d257fe572eec4736961fd4051201c3edfcdaf428d).
Mathematical argument: {BASE / 'a7-critical-argument/a7-t1-exact-transfer-derivation.md'} and a7-t1-exact-transfer-typing-companion.md. Manuscript: paper/submission-manuscript.md, exact-transfers T1/A6 passage.
Build evidence: Main EXIT0 225.82s, Checks EXIT0 36.05s, aggregate0. Checks stdout44297 bytes SHAe31cc7b2f0631afa0024c2952a59951826bec4b09ed0d28c975e7c2db10eaa94;45 printed profiles all [propext, Classical.choice, Quot.sound], stderr0.
Root independently verified1183 cached objects,2632 overlay objects,216 immutable own source pins,2 new objects, all hashes match. This is cached development provenance, NOT a fresh-source rebuild or a complete transitive axiom audit. High fresh-source debt from own321 CanonicalFlag remains OPEN. Trace imports only as needed; clearly state graph traversal limits and never equate pin equality with source compilation.
Bounded theorem scope: actual T1IndexTriple(C internal to A, K=H/B quotient image, Xbar:K~A/C), both-direction t1TripleEquiv with Hom(A,W/B) and unconditional t1Triple_card=2^(dimA*codimB); actual H/B~K and canonical A/C embedding in V/C; selected theta and exact C=Y(B) intersect A and H=B+Y^-1(A); actual pullback representative formulas, full independently realized R range, image disjointness, forward rankPrecedes and forward active triple; generic finite-dimensional rank-decomposition/agreement, arbitrary pullback kernel/range, and exact encoded-map/pullback iff.
Critical scope limitation: t1SelectedTriple_unique in this immutable source still assumes ht: encoded map equals selected theta. It is ONLY an internal conditional injectivity helper. Actual active=>ordinary and forced-triple uniqueness are on a separate uncompiled successor and NOT certified by own409. No unselected-frequency exclusion or full T1 phase/common-domain Fourier identity, Holder/A6 assembly, T2, A8/A9, full A7, HC46, outward supporting certification, full manuscript claim, or final provider gates is discharged by own409. No narrower substitute should receive full transfer credit.
Review checks: exact finite binary carriers, arbitrary subspaces and zero cases, actual map directions and transposes, no cardinality/rank premise replacing proved obligation, no disjointness-only leap to full R range, no alias/type conflation, standard axiom profiles and complete diagnostics, valid claims labels. Original campaign sequence and exact manuscript scope remain intact. Three-lens and final Claude Opus5.5/AGY Gemini3.1 Pro High gates remain required; no OpenCode/Grok.
Expected artifact: final read-only review report with verdict GO / GO-WITH-NOTES / NO-GO / INCOMPLETE, precise bounded scope, numbered HIGH/MEDIUM/LOW findings with exact paths/declarations, what you verified versus inferred, unresolved implications/debt, and concrete next action. Do not report a plausible roadmap as validated. Use fresh acceptance evidence only within its actual scope. Do not demand routine Root per-compile approval.
'''
    focuses = {
        'proof-adversarial': 'Audit mathematical sufficiency and Lean theorem hypotheses for the bounded forward/count/transport declarations; check both equivalence inverses, pullback kernel/image, independently realized direct sum, rank agreement, and conditional uniqueness boundary.',
        'complexity-theory': 'Audit obligation progress, quantifiers, exact 2^(ij) count including zero cases, manuscript scope preservation, real remaining reverse/Fourier gap and A6 dependencies. Detect helper packaging or false full-transfer/HC46 credit.',
        'non-claims-boundary': 'Audit claims and evidence labels: argument reviewed versus translated versus certified; bounded forward/count ingredient versus complete T1/A7/HC46/manuscript; cached provenance versus fresh rebuild; review debt and final provider gates.',
    }
    for role in ROLES:
        (PACKET / (role + '.prompt.txt')).write_text(common.replace('ROLE', role) + '\nLens focus: ' + focuses[role] + '\n', encoding='utf-8')
    print(json.dumps({'packet': str(PACKET), 'roles': ROLES, 'input_count': len(index)}))
else:
    role = sys.argv[1]
    if role not in ROLES:
        raise RuntimeError('unknown role')
    terminal_path = PACKET / (role + '.terminal.json')
    process_path = PACKET / (role + '.process.json')
    if terminal_path.exists() or process_path.exists():
        raise RuntimeError('retain existing reviewer owner; no duplicate')
    prompt_path = PACKET / (role + '.prompt.txt')
    command = ['C:/Program Files/nodejs/node.EXE', 'C:/Users/Dan/AppData/Roaming/npm/node_modules/@openai/codex/bin/codex.js',
               'exec', '-m', 'gpt-6-astra', '-c', 'model_reasoning_effort="xhigh"', '-s', 'read-only',
               '-C', str(ROOT), '--json', '-o', str(PACKET / (role + '.final.txt')), '-']
    started = time.monotonic()
    with (PACKET / (role + '.raw.jsonl')).open('wb') as out, (PACKET / (role + '.stderr')).open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.PIPE, stdout=out, stderr=err)
        write_json(process_path, {'pid': process.pid, 'invocation': command, 'prompt_sha256': sha(prompt_path),
                                 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'owner': 'Root top-level native CLI reviewer'})
        process.communicate(prompt_path.read_bytes())
    result = {'exit_code': process.returncode, 'seconds': round(time.monotonic() - started, 2),
              'final_exists': (PACKET / (role + '.final.txt')).is_file(), 'role': role}
    write_json(terminal_path, result)
    print(json.dumps(result))
    sys.exit(process.returncode)
