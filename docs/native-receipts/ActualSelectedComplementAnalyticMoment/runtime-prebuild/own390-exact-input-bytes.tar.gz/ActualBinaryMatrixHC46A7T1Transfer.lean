import PvNP.RealizableHardness.ActualBinaryMatrixHC46DR6Incidence
import PvNP.RealizableHardness.ActualBinaryMatrixHC46A7HybridW6Transport

/-! T1 exact-transfer structures on the actual finite F2 carriers.

The index triple is represented by C <= A, the quotient subspace H/B <= W/B,
and the manuscript isomorphism H/B ~= A/C.  The actual ambient H is recovered
as the preimage of H/B under W -> W/B.  This representation keeps the
quotient carriers explicit; it does not identify the quotient isomorphism,
its pullback H -> V/C, and the original map q_C Y|H.
-/

namespace PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer

open scoped BigOperators

set_option autoImplicit false
noncomputable section
attribute [local instance] Classical.propDecidable

open PvNP.RealizableHardness.ActualBinaryMatrixHC46A7WeightedPredecessor

private abbrev F := ZMod 2
private abbrev V (d : Nat) := Fin d -> F
private abbrev W (n : Nat) := Fin n -> F

/-- A T1 index triple. `K` is the actual quotient subspace H/B in W/B;
`Xbar` has the manuscript direction H/B ~= A/C. -/
structure T1IndexTriple {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n)) where
  C : Submodule F A
  K : Submodule F (W n ⧸ B)
  Xbar : K ≃ₗ[F] (A ⧸ C)

/-- Encode the triple by theta : A -> W/B, with the quotient map first,
then Xbar inverse, then the inclusion H/B -> W/B. -/
def t1TripleToMap {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) : A →ₗ[F] (W n ⧸ B) :=
  t.K.subtype.comp (t.Xbar.symm.toLinearMap.comp t.C.mkQ)

/-- Build the quotient triple associated to theta using its kernel and range.
C is the kernel subspace inside A; its ambient image in V is induced by A's
subtype. K is im(theta)=H/B. -/
def t1MapToTriple {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (theta : A →ₗ[F] (W n ⧸ B)) : T1IndexTriple A B where
  C := LinearMap.ker theta
  K := LinearMap.range theta
  Xbar := theta.quotKerEquivRange.symm

/-- The triple-to-map-to-triple direction recovers theta on every vector. -/
theorem t1TripleToMap_mapToTriple {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (theta : A →ₗ[F] (W n ⧸ B)) :
    t1TripleToMap (t1MapToTriple theta) = theta := by
  classical
  ext a
  change ((theta.quotKerEquivRange
    (theta.ker.mkQ a) : LinearMap.range theta)) = theta a
  rw [LinearMap.quotKerEquivRange_apply_mk]
  rfl
  rfl]

/-- The map encoded by a triple has exactly C as its kernel. -/
theorem t1TripleToMap_ker {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) :
    LinearMap.ker (t1TripleToMap t) = t.C := by
  ext a
  simp [t1TripleToMap]

/-- The map encoded by a triple has exactly K=H/B as its range. -/
theorem t1TripleToMap_range {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) :
    LinearMap.range (t1TripleToMap t) = t.K := by
  ext y
  constructor
  · rintro ⟨a, rfl⟩
    exact (t.Xbar.symm (t.C.mkQ a)).property
  · intro hy
    obtain ⟨a, ha⟩ := Submodule.mkQ_surjective t.C (t.Xbar ⟨y, hy⟩)
    have heq : ((t.Xbar.symm (t.C.mkQ a) : t.K) : W n ⧸ B) = y := by
      change ((t.Xbar.symm (t.C.mkQ a) : t.K) : W n ⧸ B) = y
      rw [ha]
      simp
    exact ⟨a, heq⟩

/-- Reconstructing the index triple from its encoded map recovers C and K. -/
theorem t1MapToTriple_CK_roundTrip {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) :
    (t1MapToTriple (t1TripleToMap t)).C = t.C ∧
      (t1MapToTriple (t1TripleToMap t)).K = t.K := by
  constructor
  · exact t1TripleToMap_ker t
  · exact t1TripleToMap_range t

/-- The map encoding is injective: its kernel, range, and the induced
quotient isomorphism recover all three fields of the index triple. -/
theorem t1TripleToMap_injective {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    {t s : T1IndexTriple A B}
    (h : t1TripleToMap t = t1TripleToMap s) : t = s := by
  cases t with
  | mk tC tK tX =>
    cases s with
    | mk sC sK sX =>
      have hC : tC = sC := by
        calc
          tC = LinearMap.ker (t1TripleToMap ⟨tC, tK, tX⟩) :=
            (t1TripleToMap_ker ⟨tC, tK, tX⟩).symm
          _ = LinearMap.ker (t1TripleToMap ⟨sC, sK, sX⟩) := congrArg LinearMap.ker h
          _ = sC := t1TripleToMap_ker ⟨sC, sK, sX⟩
      subst sC
      have hK : tK = sK := by
        calc
          tK = LinearMap.range (t1TripleToMap ⟨tC, tK, tX⟩) :=
            (t1TripleToMap_range ⟨tC, tK, tX⟩).symm
          _ = LinearMap.range (t1TripleToMap ⟨tC, sK, sX⟩) := congrArg LinearMap.range h
          _ = sK := t1TripleToMap_range ⟨tC, sK, sX⟩
      subst sK
      have hX : tX = sX := by
        apply LinearEquiv.ext
        intro k
        obtain ⟨a, ha⟩ := Submodule.mkQ_surjective tC (tX k)
        have hback : tX.symm (tC.mkQ a) = sX.symm (tC.mkQ a) := by
          apply tK.subtype.injective
          exact congrFun h a
        have hvalue := congrArg sX.toLinearMap hback
        simpa [ha] using hvalue.symm
      subst sX
      rfl

/-- Actual index triples and maps A -> W/B are equivalent in both
directions, with the two inverse laws proved above. -/
noncomputable def t1TripleEquiv {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n)) :
    T1IndexTriple A B ≃ (A →ₗ[F] (W n ⧸ B)) where
  toFun := t1TripleToMap
  invFun := t1MapToTriple
  left_inv t := by
    apply t1TripleToMap_injective
    exact t1TripleToMap_mapToTriple A B (t1TripleToMap t)
  right_inv theta := t1TripleToMap_mapToTriple A B theta

/-- The exact cardinality of all T1 index triples, with zero-dimensional
cases included. -/
theorem t1Triple_card {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n)) :
    Fintype.card (T1IndexTriple A B) =
      2 ^ (Module.finrank F A * Module.finrank F (W n ⧸ B)) := by
  classical
  letI : Fintype A := Fintype.ofFinite A
  letI : Fintype (W n ⧸ B) := Fintype.ofFinite _
  letI : Fintype (A →ₗ[F] (W n ⧸ B)) := FunLike.fintype _
  let e := t1TripleEquiv A B
  letI : Fintype (T1IndexTriple A B) := Fintype.ofEquiv _ e.symm
  rw [Fintype.card_congr e.toEquiv]
  exact w6_card_linearMap_binary

/-- Recover the actual ambient H from its quotient subspace K=H/B. -/
def t1AmbientH {n : Nat} {B : Submodule F (W n)}
    (K : Submodule F (W n ⧸ B)) : Submodule F (W n) :=
  K.comap (Submodule.mkQ B)

/-- The quotient map sends the recovered H onto the original quotient
subspace K. -/
theorem t1AmbientH_quotientRange {n : Nat}
    (B : Submodule F (W n)) (K : Submodule F (W n ⧸ B)) :
    LinearMap.range
      ((Submodule.mkQ B).comp (t1AmbientH K).subtype) = K := by
  ext x
  constructor
  · rintro ⟨w, rfl⟩
    exact w.2
  · intro hx
    obtain ⟨w, hw⟩ := Submodule.mkQ_surjective B x
    have hwmem : w ∈ t1AmbientH K := by
      change Submodule.mkQ B w ∈ K
      rw [hw]
      exact hx
    exact ⟨⟨w, hwmem⟩, hw⟩

/-- The recovered ambient H contains B, including when K is zero. -/
theorem t1AmbientH_containsB {n : Nat}
    (B : Submodule F (W n)) (K : Submodule F (W n ⧸ B)) :
    B ≤ t1AmbientH K := by
  intro b hb
  change Submodule.mkQ B b ∈ K
  have hzero : Submodule.mkQ B b = 0 := by
    rw [Submodule.mkQ_apply]
    exact Submodule.mk_eq_zero.mpr hb
  rw [hzero]
  exact K.zero_mem

/-- Quotienting the recovered H by its copy of B gives exactly K. -/
noncomputable def t1AmbientHQuotientEquiv {n : Nat}
    (B : Submodule F (W n)) (K : Submodule F (W n ⧸ B)) :
    (t1AmbientH K ⧸ B.comap (t1AmbientH K).subtype) ≃ₗ[F] K := by
  let H := t1AmbientH K
  let qH : H →ₗ[F] (W n ⧸ B) := (Submodule.mkQ B).comp H.subtype
  have hker : LinearMap.ker qH = B.comap H.subtype := by
    ext h
    change qH h = 0 ↔ H.subtype h ∈ B
    simp [qH, Submodule.mkQ_apply, Submodule.mk_eq_zero]
  have hrange : LinearMap.range qH = K := by
    simpa [qH, H] using t1AmbientH_quotientRange B K
  let e0 := qH.quotKerEquivRange
  let eqQuot : (H ⧸ B.comap H.subtype) ≃ₗ[F] (H ⧸ LinearMap.ker qH) :=
    LinearEquiv.ofEq _ _
      (congrArg (fun S : Submodule F H => H ⧸ S) hker.symm)
  exact eqQuot.trans (e0.trans (LinearEquiv.ofEq _ _ hrange))

end
end PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer
