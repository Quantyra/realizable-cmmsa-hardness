import PvNP.RealizableHardness.ActualBinaryMatrixHC46A7EnergyConsumer
import PvNP.RealizableHardness.ActualBinaryMatrixHC46A20SquareSupport
import PvNP.RealizableHardness.ActualBinaryMatrixHC46A18OriginalGlobalInduction
import PvNP.RealizableHardness.ActualBinaryMatrixHC46TypedFourierTransport
import PvNP.RealizableHardness.BinaryMatrixA1Complex
import PvNP.RealizableHardness.BinaryMatrixA1TypedFourier

/-! W6 transport on the physical Hom carrier of an actual hybrid derivative.
The W6 predecessor selector remains rank-additive, distinct from A1's hybrid
selector. The nested quotient/kernel equivalence is representative preserving. -/

namespace PvNP.RealizableHardness.ActualBinaryMatrixHC46A7HybridW6Transport

open PvNP.RealizableHardness.ActualBinaryMatrixHC46A7EnergyConsumer
open PvNP.RealizableHardness.ActualBinaryMatrixHC46A7WeightedPredecessor
open PvNP.RealizableHardness.ActualBinaryMatrixHC46A18OriginalGlobalInduction
open PvNP.RealizableHardness.ActualBinaryMatrixHC46TypedFourierTransport
open PvNP.RealizableHardness.BinaryMatrixA1Complex
open PvNP.RealizableHardness.BinaryMatrixA1TypedFourier
open PvNP.RealizableHardness.BinaryMatrixA1Phase
open PvNP.RealizableHardness.BinaryMatrixFourier
open scoped BigOperators

set_option autoImplicit false
noncomputable section
attribute [local instance] Classical.propDecidable
attribute [local instance] Fintype.ofFinite

private abbrev F := ZMod 2
private abbrev V (d : Nat) := Fin d -> F
private abbrev W (n : Nat) := Fin n -> F

/-- Rank-additive predecessor relation on the dual of an actual Hom carrier. -/
def typedW6Precedes {n d : Nat} (A : Submodule F (V d))
    (B : Submodule F (W n))
    (Z Z' : B ->ₗ[F] (V d ⧸ A)) : Prop :=
  Module.finrank F (LinearMap.range Z') =
    Module.finrank F (LinearMap.range Z) +
      Module.finrank F (LinearMap.range (Z' - Z))

/-- The matrix rank-additive selector is exactly the typed selector after the
actual transpose-aware dual frequency equivalence. -/
theorem typedW6Precedes_coordinate_iff {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Z Z' : B ->ₗ[F] (V d ⧸ A)) :
    w6Precedes (carrierFrequencyEquiv A B Z)
      (carrierFrequencyEquiv A B Z') <-> typedW6Precedes A B Z Z' := by
  unfold w6Precedes typedW6Precedes
  have hZ := carrierFrequency_rank A B Z
  have hZ' := carrierFrequency_rank A B Z'
  have hdiff := carrierFrequency_rank A B (Z' - Z)
  have hmap : carrierFrequencyEquiv A B (Z' - Z) =
      carrierFrequencyEquiv A B Z' - carrierFrequencyEquiv A B Z := by
    simp
  rw [← hZ', ← hZ, ← hdiff, hmap]

/-- Equality of the actual coordinate transpose map and the linear map
`J=u o Z o b^{-1}`. The matrix `Y` is not identified with this map. -/
theorem carrierFrequency_to_coordinateMap {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Z : B ->ₗ[F] (V d ⧸ A)) :
    (carrierFrequencyEquiv A B Z).transpose.toLin' =
      (domainBasis A).equivFun.toLinearMap.comp
        (Z.comp (codomainBasis B).equivFun.symm.toLinearMap) :=
  carrierFrequency_toLin A B Z

/-- The actual transpose range, pulled back by the domain basis, is the
image of the typed frequency. -/
theorem carrierFrequency_range_pullback {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Z : B ->ₗ[F] (V d ⧸ A)) :
    (LinearMap.range (carrierFrequencyEquiv A B Z).transpose.toLin').map
        (domainBasis A).equivFun.symm.toLinearMap = LinearMap.range Z := by
  let u := (domainBasis A).equivFun
  let b := (codomainBasis B).equivFun
  let J := u.toLinearMap.comp (Z.comp b.symm.toLinearMap)
  have hJ : (carrierFrequencyEquiv A B Z).transpose.toLin' = J := by
    exact carrierFrequency_to_coordinateMap A B Z
  have hpre : LinearMap.range (Z.comp b.symm.toLinearMap) =
      LinearMap.range Z := by
    apply le_antisymm
    · exact LinearMap.range_comp_le_range _ _
    · rintro x ⟨y, rfl⟩
      refine ⟨b (b.symm y), ?_⟩
      simp
  calc
    _ = (LinearMap.range J).map u.symm.toLinearMap := by rw [hJ]
    _ = ((LinearMap.range (Z.comp b.symm.toLinearMap)).map
          u.toLinearMap).map u.symm.toLinearMap := by
            rw [J, LinearMap.range_comp]
    _ = LinearMap.range Z := by
      rw [hpre, Submodule.map_comp]
      simp [u]

/-- The actual transpose kernel, pulled back by the codomain basis, is the
kernel of the typed frequency. -/
theorem carrierFrequency_kernel_pullback {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Z : B ->ₗ[F] (V d ⧸ A)) :
    (LinearMap.ker (carrierFrequencyEquiv A B Z).transpose.toLin').map
        (codomainBasis B).equivFun.symm.toLinearMap = LinearMap.ker Z := by
  let u := (domainBasis A).equivFun
  let b := (codomainBasis B).equivFun
  have hJ : (carrierFrequencyEquiv A B Z).transpose.toLin' =
      u.toLinearMap.comp (Z.comp b.symm.toLinearMap) :=
    carrierFrequency_to_coordinateMap A B Z
  ext x
  constructor
  · intro hx
    rcases Submodule.mem_map.mp hx with ⟨y, hy, hxy⟩
    have hy0 : (carrierFrequencyEquiv A B Z).transpose.toLin' y = 0 :=
      LinearMap.mem_ker.mp hy
    have hz0 : Z (b.symm y) = 0 := by
      apply u.injective
      simpa [hJ] using hy0
    rw [← hxy] at hz0
    exact LinearMap.mem_ker.mpr hz0
  · intro hx
    refine Submodule.mem_map.mpr ⟨b x, ?_, by simp [b]⟩
    apply LinearMap.mem_ker.mpr
    rw [hJ]
    simp [hx]

/-- Explicit actual coordinate equivalence from the W6 output carrier to the
typed quotient/kernel Hom. Its inverse is `N -> bker o N o ubar^{-1}`. -/
noncomputable def typedW6OutputCoordinateEquiv {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Z : B ->ₗ[F] (V d ⧸ A)) :
    (((V d ⧸ A) ⧸ LinearMap.range Z) ->ₗ[F] LinearMap.ker Z) ≃ₗ[F]
      (((Fin (Module.finrank F (V d ⧸ A)) -> F) ⧸
        LinearMap.range (carrierFrequencyEquiv A B Z).transpose.toLin') ->ₗ[F]
        LinearMap.ker (carrierFrequencyEquiv A B Z).transpose.toLin') := by
  let C := LinearMap.range (carrierFrequencyEquiv A B Z).transpose.toLin'
  let D := LinearMap.ker (carrierFrequencyEquiv A B Z).transpose.toLin'
  let u := (domainBasis A).equivFun
  let b := (codomainBasis B).equivFun
  have hC : C.map u.symm.toLinearMap = LinearMap.range Z :=
    carrierFrequency_range_pullback A B Z
  have hD : D.map b.symm.toLinearMap = LinearMap.ker Z :=
    carrierFrequency_kernel_pullback A B Z
  let eQ := Submodule.Quotient.equiv C (LinearMap.range Z) u.symm hC
  let eK0 := Submodule.equivMapOfInjective b.symm.toLinearMap
    b.symm.injective D
  let eK := eK0.trans (LinearEquiv.ofEq _ _ hD)
  exact (LinearEquiv.arrowCongr eQ eK).symm

/-- Physical coordinate representative of the actual A1 hybrid derivative.
The domain is `Hom(V/A,B)`; the frequency carrier is its dual. -/
def hybridInputCoordinate {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (T : V d ->ₗ[F] W n) (f : BinaryMatrix n d -> Complex)
    (K : BinaryMatrix (Module.finrank F B)
      (Module.finrank F (V d ⧸ A))) : Complex :=
  filteredCarrierFunction A B T f ((carrierMatrixEquiv A B).symm K)

/-- The exact A11 hybrid input has carrier Fourier support through the same
`D`, including the cost-too-large zero case. -/
theorem hybridInputCoordinate_supportedThrough {n d D : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (T : V d ->ₗ[F] W n) (f : BinaryMatrix n d -> Complex)
    (hsupport : ComplexFourierSupportedThrough D f) :
    ComplexFourierSupportedThrough D (hybridInputCoordinate A B T f) := by
  apply (carrierFourier_support_iff_coordinate A B D
    (filteredCarrierFunction A B T f)).1
  exact filteredCarrierFunction_supportedThrough A B T f hsupport

/-- Actual coordinate W6 estimate for the physical coordinate image of every
actual hybrid derivative, at inner base zero and the common original degree D. -/
theorem hybridInputCoordinate_w6_le_two {n d D : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (T : V d ->ₗ[F] W n) (f : BinaryMatrix n d -> Complex)
    (hsupport : ComplexFourierSupportedThrough D f) :
    (∑ X : BinaryMatrix (Module.finrank F B)
      (Module.finrank F (V d ⧸ A)), (carrierMean (LinearMap.range X.transpose.toLin')
        (LinearMap.ker X.transpose.toLin')
        (fun M => Complex.normSq
          (actualW6Derivative X 0 (hybridInputCoordinate A B T f) M)))^2 /
          (2 : Real)^(6 * D * X.rank)) <=
      2 * (uniformMean (fun K => Complex.normSq
        (hybridInputCoordinate A B T f K)))^2 := by
  exact actualW6Derivative_weighted_fourth_moment_le_two
    (T := 0) (hybridInputCoordinate A B T f)
    (hybridInputCoordinate_supportedThrough A B T f hsupport)

end
end PvNP.RealizableHardness.ActualBinaryMatrixHC46A7HybridW6Transport
