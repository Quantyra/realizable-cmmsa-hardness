import Mathlib.Tactic
import PvNP.RealizableHardness.ActualBinaryMatrixHC46DR6Convolution
import PvNP.RealizableHardness.ActualBinaryMatrixHC46A12FourthMoment

/-!
The DR6 F1 fourth-moment engine, under the exact ordinary-selector scope.

The manuscript permits complex-valued inputs `f`; only its final indicator is
real. Thus the positive F1 weights are `norm (complexFourierCoeff f (A+C))`.
The proof uses direct Gram Cauchy, not a reality, Booleanity, or
hypercontractivity premise.

For an F1 triple `X= A+B`, `Y=A+C`, `Z=B+C`, the witness includes all three
pairwise image intersections equal to bottom and the three exact rank
additivities.  At a fixed output X, assigning a witness to each contributing
F1 pair is injective into witness triples (A,B,C): the triple recovers Y,Z.
Group these triples by their outer pair (A,B), and sum over C inside
`H(A,B)`; do not count triples as distinct outer splits.  Each outer split is
a predecessor of X, so there are at most
`2^(rank X ^ 2) <= 2^(4D^2)` of them when `rank X <= 2D`. For the remaining
common summand C, put `c(A,C)=norm(fhat(A+C))` on direct supported A,C pairs
and zero otherwise, and `H(A,B)=sum_C c(A,C)c(B,C)`. The F1 witness sum is
bounded by `sum_(A,B):A+B=X H(A,B)`. Finite Cauchy-Schwarz bounds the squared
Frobenius norm of H by the square of its coefficient mass. The exact direct-Y
split count and complex Parseval bound that mass by
`2^(D^2)||f||_2^2`. Rank zero is included.

This is the full F1 moment estimate. It does not certify the separate F2
Möbius estimate or the full DR6 theorem.
-/

namespace PvNP.RealizableHardness.ActualBinaryMatrixHC46DR6SignMoments

open PvNP.RealizableHardness.BinaryMatrixFourier
open PvNP.RealizableHardness.BinaryMatrixA1Complex
open PvNP.RealizableHardness.ActualBinaryMatrixHC46DR6Convolution
open PvNP.RealizableHardness.ActualBinaryMatrixHC46A12FourthMoment
open PvNP.RealizableHardness.ActualFiniteDegreeFourierReconstruction
open scoped BigOperators

set_option autoImplicit false
noncomputable section
attribute [local instance] Classical.propDecidable

/-- The exact complex Fourier coefficient weight used by manuscript F1.
The cutoff is on the frequency `A+C`; the complex input itself is not
restricted to be real-valued. -/
def dr6ActualPhiCoefficient {n d D : Nat}
    (f : BinaryMatrix n d → Complex) (A C : BinaryMatrix n d) : Real :=
  if LinearMap.range A.transpose.toLin' ⊓
        LinearMap.range C.transpose.toLin' = ⊥ ∧
      (A + C).rank = A.rank + C.rank ∧ (A + C).rank ≤ D then
    norm (complexFourierCoeff f (A + C))
  else 0

/-- The nonnegative Gram coefficients that collect the shared summand C
inside each outer pair (A,B). -/
def dr6ActualPhiGram {n d D : Nat}
    (f : BinaryMatrix n d → Complex) (A B : BinaryMatrix n d) : Real :=
  ∑ C : BinaryMatrix n d,
    dr6ActualPhiCoefficient (D := D) f A C *
      dr6ActualPhiCoefficient (D := D) f B C

theorem dr6_actual_phi_coefficient_nonneg {n d D : Nat}
    (f : BinaryMatrix n d → Complex) (A C : BinaryMatrix n d) :
    0 ≤ dr6ActualPhiCoefficient (D := D) f A C := by
  unfold dr6ActualPhiCoefficient
  split_ifs <;> positivity

theorem dr6_actual_phi_gram_nonneg {n d D : Nat}
    (f : BinaryMatrix n d → Complex) (A B : BinaryMatrix n d) :
    0 ≤ dr6ActualPhiGram (D := D) f A B := by
  unfold dr6ActualPhiGram
  apply Finset.sum_nonneg
  intro C hC
  exact mul_nonneg (dr6_actual_phi_coefficient_nonneg f A C)
    (dr6_actual_phi_coefficient_nonneg f B C)

private def dr6ActualPhiRowEnergy {n d D : Nat}
    (f : BinaryMatrix n d → Complex) (A : BinaryMatrix n d) : Real :=
  ∑ C : BinaryMatrix n d,
    dr6ActualPhiCoefficient (D := D) f A C ^ 2

/-- Total squared mass of the actual supported direct-split coefficients. -/
def dr6ActualPhiCoefficientMass {n d D : Nat}
    (f : BinaryMatrix n d → Complex) : Real :=
  ∑ A : BinaryMatrix n d, dr6ActualPhiRowEnergy (D := D) f A

private def dr6ActualSupportedDirectPair {n d D : Nat}
    (f : BinaryMatrix n d → Complex) :=
  {p : BinaryMatrix n d × BinaryMatrix n d //
    LinearMap.range p.1.transpose.toLin' ⊓
        LinearMap.range p.2.transpose.toLin' = ⊥ ∧
      (p.1 + p.2).rank = p.1.rank + p.2.rank ∧
      (p.1 + p.2).rank ≤ D}

private noncomputable instance dr6ActualSupportedDirectPairFintype
    {n d D : Nat} (f : BinaryMatrix n d → Complex) :
    Fintype (dr6ActualSupportedDirectPair (D := D) f) := by
  classical
  unfold dr6ActualSupportedDirectPair
  infer_instance

/-- The actual coefficient mass is bounded by the supported direct-split
fibers, then by their rank-scale count and complex Parseval. -/
theorem dr6_actual_phi_coefficient_mass_le_parseval {n d D : Nat}
    (f : BinaryMatrix n d → Complex)
    (hsupport : ComplexFourierSupportedThrough D f) :
    dr6ActualPhiCoefficientMass (D := D) f ≤
      (2^(D * D) : Real) * uniformMean (fun M => Complex.normSq (f M)) := by
  classical
  let P := dr6ActualSupportedDirectPair (D := D) f
  let pred : BinaryMatrix n d × BinaryMatrix n d → Prop := fun z =>
    LinearMap.range z.1.transpose.toLin' ⊓
        LinearMap.range z.2.transpose.toLin' = ⊥ ∧
      (z.1 + z.2).rank = z.1.rank + z.2.rank ∧
      (z.1 + z.2).rank ≤ D
  let weight : BinaryMatrix n d × BinaryMatrix n d → Real := fun z =>
    if pred z then Complex.normSq (complexFourierCoeff f (z.1 + z.2)) else 0
  let Q := Σ Y : BinaryMatrix n d, DR6DirectYDecomposition Y
  let e : P → Q := fun p =>
    ⟨p.1.1 + p.1.2, ⟨p.1, rfl, p.2.1, p.2.2.1⟩⟩
  have he : Function.Injective e := by
    intro p q hpq
    apply Subtype.ext
    apply Prod.ext
    · exact congrArg (fun z : Q => z.2.val.1) hpq
    · exact congrArg (fun z : Q => z.2.val.2) hpq
  have hcompl : (∑ z : {z : BinaryMatrix n d × BinaryMatrix n d // ¬ pred z},
      weight z.val) = 0 := by
    apply Finset.sum_eq_zero
    intro z hz
    simp [weight, z.property]
  have hpartition :=
    (Fintype.sum_subtype_add_sum_subtype pred weight).symm
  rw [hcompl, add_zero] at hpartition
  have hmass : dr6ActualPhiCoefficientMass (D := D) f =
      ∑ p : P, Complex.normSq
        (complexFourierCoeff f (p.val.1 + p.val.2)) := by
    calc
      dr6ActualPhiCoefficientMass (D := D) f =
          ∑ z : BinaryMatrix n d × BinaryMatrix n d, weight z := by
        simp [dr6ActualPhiCoefficientMass, dr6ActualPhiRowEnergy,
          dr6ActualPhiCoefficient, dr6ActualSupportedDirectPair,
          pred, weight, Fintype.sum_prod_type,
          Complex.normSq_eq_norm_sq]
      _ = ∑ p : P, Complex.normSq
          (complexFourierCoeff f (p.val.1 + p.val.2)) := by
        calc
          _ = ∑ p : P, weight p.val := by
            simpa [P, dr6ActualSupportedDirectPair] using hpartition
          _ = _ := by
            apply Fintype.sum_congr
            intro p
            simp [weight, pred, P, dr6ActualSupportedDirectPair, p.property]
  rw [hmass]
  have hembed :
      (∑ p : P, Complex.normSq
        (complexFourierCoeff f (p.val.1 + p.val.2))) ≤
      ∑ q : Q, Complex.normSq (complexFourierCoeff f q.1) := by
    apply Finset.sum_le_sum_of_injOn
      (s := Finset.univ) (t := Finset.univ) e
    · intro p hp q hq hpq
      exact he hpq
    · intro q hq
      exact Finset.mem_univ q
    · intro p hp
      rfl
    · intro q hq hnot
      exact Complex.normSq_nonneg _
  have hfiber :
      (∑ q : Q, Complex.normSq (complexFourierCoeff f q.1)) ≤
      (2^(D * D) : Real) *
        ∑ Y : BinaryMatrix n d, Complex.normSq (complexFourierCoeff f Y) := by
    rw [Finset.mul_sum, Fintype.sum_sigma]
    apply Finset.sum_le_sum
    intro Y hY
    by_cases hYr : Y.rank ≤ D
    · have hcard :
          (Fintype.card (DR6DirectYDecomposition Y) : Real) ≤
            (2^(D * D) : Real) := by
        calc
          (Fintype.card (DR6DirectYDecomposition Y) : Real) ≤
              (2^(Y.rank * Y.rank) : Real) := by
                exact_mod_cast dr6_y_decomposition_card_le_pow Y
          _ ≤ (2^(D * D) : Real) := by
                have hexp : Y.rank * Y.rank ≤ D * D :=
                  Nat.mul_le_mul hYr hYr
                exact_mod_cast
                  (Nat.pow_le_pow_right (by decide : 0 < 2) hexp)
      simpa [Finset.sum_const, nsmul_eq_mul] using
        (mul_le_mul_of_nonneg_right hcard
          (Complex.normSq_nonneg (complexFourierCoeff f Y)))
    · have hzero : complexFourierCoeff f Y = 0 :=
        hsupport Y (Nat.lt_of_not_ge hYr)
      rw [hzero]
  calc
    _ ≤ ∑ q : Q, Complex.normSq (complexFourierCoeff f q.1) := hembed
    _ ≤ (2^(D * D) : Real) *
          ∑ Y : BinaryMatrix n d, Complex.normSq (complexFourierCoeff f Y) := hfiber
    _ = (2^(D * D) : Real) * uniformMean
          (fun M => Complex.normSq (f M)) := by
          rw [← ActualBinaryMatrixHC46A12FourthMoment.complex_fourier_parseval]

/-- Finite Cauchy-Schwarz bounds the squared Frobenius norm of the actual
nonnegative Gram matrix by the square of its coefficient mass. -/
theorem dr6_actual_phi_gram_frobenius_le_mass {n d D : Nat}
    (f : BinaryMatrix n d → Complex) :
    (∑ A : BinaryMatrix n d, ∑ B : BinaryMatrix n d,
      dr6ActualPhiGram (D := D) f A B ^ 2) ≤
      dr6ActualPhiCoefficientMass (D := D) f ^ 2 := by
  classical
  have hentry (A B : BinaryMatrix n d) :
      dr6ActualPhiGram (D := D) f A B ^ 2 ≤
        dr6ActualPhiRowEnergy (D := D) f A *
          dr6ActualPhiRowEnergy (D := D) f B := by
    simpa [dr6ActualPhiGram, dr6ActualPhiRowEnergy, pow_two] using
      (Finset.sum_mul_sq_le_sq_mul_sq
        (Finset.univ : Finset (BinaryMatrix n d))
        (fun C => dr6ActualPhiCoefficient (D := D) f A C)
        (fun C => dr6ActualPhiCoefficient (D := D) f B C))
  calc
    _ ≤ ∑ A : BinaryMatrix n d, ∑ B : BinaryMatrix n d,
          dr6ActualPhiRowEnergy (D := D) f A *
            dr6ActualPhiRowEnergy (D := D) f B := by
      apply Finset.sum_le_sum
      intro A hA
      apply Finset.sum_le_sum
      intro B hB
      exact hentry A B
    _ = dr6ActualPhiCoefficientMass (D := D) f ^ 2 := by
      simp [dr6ActualPhiCoefficientMass, pow_two, Fintype.sum_mul_sum,
        mul_assoc]

/-- A single supported F1 pair is charged to the Gram entry for its outer
`(A,B)` split. The common summand remains inside that Gram entry. -/
theorem dr6_actual_f1_pair_le_gram_sum {n d D : Nat}
    (f : BinaryMatrix n d → Complex) (X Y Z : BinaryMatrix n d)
    (hFY : Y.rank ≤ D) (hFZ : Z.rank ≤ D)
    (hF1 : DR6F1Witness X Y Z) :
    norm (complexFourierCoeff f Y) *
        norm (complexFourierCoeff f Z) ≤
      ∑ p : DR6DirectYDecomposition X,
        dr6ActualPhiGram (D := D) f p.val.1 p.val.2 := by
  classical
  rcases hF1 with ⟨A, B, C, hY, hZ, hX, hAB, hAC, hBC,
    hYr, hZr, hXr⟩
  have hYr' : (A + C).rank = A.rank + C.rank := by
    rw [← hY]
    exact hYr
  have hZr' : (B + C).rank = B.rank + C.rank := by
    rw [← hZ]
    exact hZr
  have hYcut : (A + C).rank ≤ D := by rw [← hY]; exact hFY
  have hZcut : (B + C).rank ≤ D := by rw [← hZ]; exact hFZ
  have hcA : dr6ActualPhiCoefficient (D := D) f A C =
      norm (complexFourierCoeff f Y) := by
    unfold dr6ActualPhiCoefficient
    rw [if_pos ⟨hAC, hYr', hYcut⟩, ← hY]
  have hcB : dr6ActualPhiCoefficient (D := D) f B C =
      norm (complexFourierCoeff f Z) := by
    unfold dr6ActualPhiCoefficient
    rw [if_pos ⟨hBC, hZr', hZcut⟩, ← hZ]
  have hInner :
      dr6ActualPhiCoefficient (D := D) f A C *
        dr6ActualPhiCoefficient (D := D) f B C ≤
      dr6ActualPhiGram (D := D) f A B := by
    unfold dr6ActualPhiGram
    exact Finset.single_le_sum
      (fun C' hC' => mul_nonneg
        (dr6_actual_phi_coefficient_nonneg f A C')
        (dr6_actual_phi_coefficient_nonneg f B C'))
      (Finset.mem_univ C)
  let p : DR6DirectYDecomposition X :=
    ⟨(A, B), hX, hAB, hXr⟩
  have hOuter : dr6ActualPhiGram (D := D) f A B ≤
      ∑ q : DR6DirectYDecomposition X,
        dr6ActualPhiGram (D := D) f q.val.1 q.val.2 := by
    exact Finset.single_le_sum
      (fun q hq => dr6_actual_phi_gram_nonneg f q.val.1 q.val.2)
      (Finset.mem_univ p)
  calc
    _ = dr6ActualPhiCoefficient (D := D) f A C *
          dr6ActualPhiCoefficient (D := D) f B C := by rw [hcA, hcB]
    _ ≤ dr6ActualPhiGram (D := D) f A B := hInner
    _ ≤ _ := hOuter

/-- Ordinary-selector F1 additive pairs at the output `X`. -/
def dr6ActualF1Pairs {n d : Nat} (X : BinaryMatrix n d) :=
  {p : BinaryMatrix n d × BinaryMatrix n d //
    p.1 + p.2 = X ∧ DR6F1Witness X p.1 p.2}

private noncomputable instance dr6DirectYDecompositionFintype {n d : Nat}
    (Y : BinaryMatrix n d) : Fintype (DR6DirectYDecomposition Y) := by
  classical
  unfold DR6DirectYDecomposition
  infer_instance

noncomputable instance dr6ActualF1PairsFintype {n d : Nat}
    (X : BinaryMatrix n d) : Fintype (dr6ActualF1Pairs X) := by
  classical
  unfold dr6ActualF1Pairs
  infer_instance

private noncomputable def dr6ChooseF1ABC {n d : Nat} {X : BinaryMatrix n d}
    (p : dr6ActualF1Pairs X) :
    BinaryMatrix n d × BinaryMatrix n d × BinaryMatrix n d := by
  classical
  let h := p.property.2
  let A := Classical.choose h
  let hA := Classical.choose_spec h
  let B := Classical.choose hA
  let hB := Classical.choose_spec hA
  let C := Classical.choose hB
  exact (A, B, C)

private theorem dr6ChooseF1ABC_spec {n d : Nat} {X : BinaryMatrix n d}
    (p : dr6ActualF1Pairs X) :
    let q := dr6ChooseF1ABC p
    p.val.1 = q.1 + q.2.2 ∧ p.val.2 = q.2.1 + q.2.2 ∧
      X = q.1 + q.2.1 ∧
      LinearMap.range q.1.transpose.toLin' ⊓
          LinearMap.range q.2.1.transpose.toLin' = ⊥ ∧
      LinearMap.range q.1.transpose.toLin' ⊓
          LinearMap.range q.2.2.transpose.toLin' = ⊥ ∧
      LinearMap.range q.2.1.transpose.toLin' ⊓
          LinearMap.range q.2.2.transpose.toLin' = ⊥ ∧
      q.1.rank + q.2.2.rank = p.val.1.rank ∧
      q.2.1.rank + q.2.2.rank = p.val.2.rank ∧
      X.rank = q.1.rank + q.2.1.rank := by
  classical
  dsimp [dr6ChooseF1ABC]
  let h := p.property.2
  let A := Classical.choose h
  have hA := Classical.choose_spec h
  let B := Classical.choose hA
  have hB := Classical.choose_spec hA
  let C := Classical.choose hB
  rcases Classical.choose_spec hB with
    ⟨hY, hZ, hX, hAB, hAC, hBC, hYr, hZr, hXr⟩
  exact ⟨hY, hZ, hX, hAB, hAC, hBC, hYr.symm, hZr.symm, hXr⟩

private theorem dr6ChooseF1ABC_injective {n d : Nat} {X : BinaryMatrix n d} :
    Function.Injective (dr6ChooseF1ABC (X := X)) := by
  intro p q hpq
  rcases dr6ChooseF1ABC_spec p with ⟨hpY, hpZ, hpX, hpAB, hpAC, hpBC,
    hpYr, hpZr, hpRank⟩
  rcases dr6ChooseF1ABC_spec q with ⟨hqY, hqZ, hqX, hqAB, hqAC, hqBC,
    hqYr, hqZr, hqRank⟩
  have hA : (dr6ChooseF1ABC p).1 = (dr6ChooseF1ABC q).1 :=
    congrArg Prod.fst hpq
  have hBC : (dr6ChooseF1ABC p).2 = (dr6ChooseF1ABC q).2 :=
    congrArg Prod.snd hpq
  have hB : (dr6ChooseF1ABC p).2.1 = (dr6ChooseF1ABC q).2.1 :=
    congrArg Prod.fst hBC
  have hC : (dr6ChooseF1ABC p).2.2 = (dr6ChooseF1ABC q).2.2 :=
    congrArg Prod.snd hBC
  apply Subtype.ext
  apply Prod.ext
  · calc
      p.val.1 = (dr6ChooseF1ABC p).1 + (dr6ChooseF1ABC p).2.2 := hpY
      _ = (dr6ChooseF1ABC q).1 + (dr6ChooseF1ABC q).2.2 := by rw [hA, hC]
      _ = q.val.1 := hqY.symm
  · calc
      p.val.2 = (dr6ChooseF1ABC p).2.1 + (dr6ChooseF1ABC p).2.2 := hpZ
      _ = (dr6ChooseF1ABC q).2.1 + (dr6ChooseF1ABC q).2.2 := by rw [hB, hC]
      _ = q.val.2 := hqZ.symm

private theorem dr6_actual_f1_pair_chosen_charge {n d D : Nat}
    (f : BinaryMatrix n d → Complex) {X : BinaryMatrix n d}
    (hsupport : ComplexFourierSupportedThrough D f)
    (p : dr6ActualF1Pairs X) :
    norm (complexFourierCoeff f p.val.1) *
        norm (complexFourierCoeff f p.val.2) ≤
      dr6ActualPhiCoefficient (D := D) f
          (dr6ChooseF1ABC p).1 (dr6ChooseF1ABC p).2.2 *
        dr6ActualPhiCoefficient (D := D) f
          (dr6ChooseF1ABC p).2.1 (dr6ChooseF1ABC p).2.2 := by
  classical
  rcases dr6ChooseF1ABC_spec p with ⟨hY, hZ, hX, hAB, hAC, hBC,
    hYr, hZr, hXr⟩
  have hYr' : ((dr6ChooseF1ABC p).1 + (dr6ChooseF1ABC p).2.2).rank =
      (dr6ChooseF1ABC p).1.rank + (dr6ChooseF1ABC p).2.2.rank := by
    rw [← hY]
    exact hYr.symm
  have hZr' : ((dr6ChooseF1ABC p).2.1 + (dr6ChooseF1ABC p).2.2).rank =
      (dr6ChooseF1ABC p).2.1.rank + (dr6ChooseF1ABC p).2.2.rank := by
    rw [← hZ]
    exact hZr.symm
  by_cases hYcut : p.val.1.rank ≤ D
  · by_cases hZcut : p.val.2.rank ≤ D
    · have hYcut' : ((dr6ChooseF1ABC p).1 +
          (dr6ChooseF1ABC p).2.2).rank ≤ D := by rw [← hY]; exact hYcut
      have hZcut' : ((dr6ChooseF1ABC p).2.1 +
          (dr6ChooseF1ABC p).2.2).rank ≤ D := by rw [← hZ]; exact hZcut
      have hcA : dr6ActualPhiCoefficient (D := D) f
          (dr6ChooseF1ABC p).1 (dr6ChooseF1ABC p).2.2 =
          norm (complexFourierCoeff f p.val.1) := by
        unfold dr6ActualPhiCoefficient
        rw [if_pos ⟨hAC, hYr', hYcut'⟩, ← hY]
      have hcB : dr6ActualPhiCoefficient (D := D) f
          (dr6ChooseF1ABC p).2.1 (dr6ChooseF1ABC p).2.2 =
          norm (complexFourierCoeff f p.val.2) := by
        unfold dr6ActualPhiCoefficient
        rw [if_pos ⟨hBC, hZr', hZcut'⟩, ← hZ]
      rw [hcA, hcB]
    · have hZzero : complexFourierCoeff f p.val.2 = 0 :=
        hsupport p.val.2 (Nat.lt_of_not_ge hZcut)
      simpa [hZzero] using mul_nonneg (dr6_actual_phi_coefficient_nonneg f
        (dr6ChooseF1ABC p).1 (dr6ChooseF1ABC p).2.2)
        (dr6_actual_phi_coefficient_nonneg f
          (dr6ChooseF1ABC p).2.1 (dr6ChooseF1ABC p).2.2)
    · have hYzero : complexFourierCoeff f p.val.1 = 0 :=
        hsupport p.val.1 (Nat.lt_of_not_ge hYcut)
    simpa [hYzero] using mul_nonneg (dr6_actual_phi_coefficient_nonneg f
      (dr6ChooseF1ABC p).1 (dr6ChooseF1ABC p).2.2)
      (dr6_actual_phi_coefficient_nonneg f
        (dr6ChooseF1ABC p).2.1 (dr6ChooseF1ABC p).2.2)

private noncomputable def dr6F1PairToOuterCommon {n d : Nat}
    {X : BinaryMatrix n d} (p : dr6ActualF1Pairs X) :
    DR6DirectYDecomposition X × BinaryMatrix n d := by
  classical
  let q := dr6ChooseF1ABC p
  have hs := dr6ChooseF1ABC_spec p
  exact (⟨(q.1, q.2.1), hs.2.2.1, hs.2.2.2.1,
    hs.2.2.2.2.2.2.2.2⟩, q.2.2)

private theorem dr6F1PairToOuterCommon_outer_val {n d : Nat}
    {X : BinaryMatrix n d} (p : dr6ActualF1Pairs X) :
    (dr6F1PairToOuterCommon p).1.val =
      ((dr6ChooseF1ABC p).1, (dr6ChooseF1ABC p).2.1) := by
  classical
  unfold dr6F1PairToOuterCommon
  dsimp
  rfl

private theorem dr6F1PairToOuterCommon_common {n d : Nat}
    {X : BinaryMatrix n d} (p : dr6ActualF1Pairs X) :
    (dr6F1PairToOuterCommon p).2 = (dr6ChooseF1ABC p).2.2 := by
  classical
  unfold dr6F1PairToOuterCommon
  rfl

private theorem dr6F1PairToOuterCommon_injective {n d : Nat}
    {X : BinaryMatrix n d} :
    Function.Injective (dr6F1PairToOuterCommon (X := X)) := by
  intro p q hpq
  have hOuter : (dr6F1PairToOuterCommon p).1.val =
      (dr6F1PairToOuterCommon q).1.val :=
    congrArg Subtype.val (congrArg Prod.fst hpq)
  rw [dr6F1PairToOuterCommon_outer_val p,
    dr6F1PairToOuterCommon_outer_val q] at hOuter
  have hA : (dr6ChooseF1ABC p).1 = (dr6ChooseF1ABC q).1 :=
    congrArg (fun z : BinaryMatrix n d × BinaryMatrix n d => z.1) hOuter
  have hB : (dr6ChooseF1ABC p).2.1 = (dr6ChooseF1ABC q).2.1 :=
    congrArg (fun z : BinaryMatrix n d × BinaryMatrix n d => z.2) hOuter
  have hC : (dr6ChooseF1ABC p).2.2 = (dr6ChooseF1ABC q).2.2 :=
    by
      have hc := congrArg
        (fun z : DR6DirectYDecomposition X × BinaryMatrix n d => z.2) hpq
      simpa only [dr6F1PairToOuterCommon_common] using hc
  apply dr6ChooseF1ABC_injective
  exact Prod.ext hA (Prod.ext hB hC)

private theorem dr6_actual_f1_weight_sum_le_gram {n d D : Nat}
    (f : BinaryMatrix n d → Complex) (X : BinaryMatrix n d)
    (hsupport : ComplexFourierSupportedThrough D f) :
    (∑ p : dr6ActualF1Pairs X,
      norm (complexFourierCoeff f p.val.1) *
        norm (complexFourierCoeff f p.val.2)) ≤
      ∑ q : DR6DirectYDecomposition X,
        dr6ActualPhiGram (D := D) f q.val.1 q.val.2 := by
  classical
  let e := dr6F1PairToOuterCommon (X := X)
  let w (p : dr6ActualF1Pairs X) :=
    norm (complexFourierCoeff f p.val.1) *
      norm (complexFourierCoeff f p.val.2)
  let g (q : DR6DirectYDecomposition X × BinaryMatrix n d) :=
    dr6ActualPhiCoefficient (D := D) f q.1.val.1 q.2 *
      dr6ActualPhiCoefficient (D := D) f q.1.val.2 q.2
  have hcharge : ∀ p : dr6ActualF1Pairs X, w p ≤ g (e p) := by
    intro p
    have h := dr6_actual_f1_pair_chosen_charge f hsupport p
    dsimp [w, g, e]
    rw [dr6F1PairToOuterCommon_outer_val p,
      dr6F1PairToOuterCommon_common p]
    exact h
  have hsum := Finset.sum_le_sum_of_injOn
    (s := Finset.univ) (t := Finset.univ) e
    (by
      intro p hp q hq heq
      exact dr6F1PairToOuterCommon_injective heq)
    (by intro q hq; exact Finset.mem_univ q)
    (by
      intro p hp
      exact hcharge p)
    (by
      intro q hq hnot
      exact mul_nonneg
        (dr6_actual_phi_coefficient_nonneg f q.1.val.1 q.2)
        (dr6_actual_phi_coefficient_nonneg f q.1.val.2 q.2))
  change (∑ p : dr6ActualF1Pairs X, w p) ≤
    ∑ q : DR6DirectYDecomposition X × BinaryMatrix n d, g q at hsum
  change (∑ p : dr6ActualF1Pairs X, w p) ≤ _
  calc
    _ ≤ ∑ q : DR6DirectYDecomposition X × BinaryMatrix n d, g q := hsum
    _ = ∑ p : DR6DirectYDecomposition X,
          dr6ActualPhiGram (D := D) f p.val.1 p.val.2 := by
      simp [g, dr6ActualPhiGram, Fintype.sum_prod_type]

private theorem dr6_actual_f1_energy_at_X_le {n d D : Nat}
    (f : BinaryMatrix n d → Complex) (X : BinaryMatrix n d)
    (hsupport : ComplexFourierSupportedThrough D f)
    (hXrank : X.rank ≤ 2 * D) :
    (∑ p : dr6ActualF1Pairs X,
      norm (complexFourierCoeff f p.val.1) *
        norm (complexFourierCoeff f p.val.2)) ^ 2 ≤
      (2^(4 * D * D) : Real) *
        (∑ p : DR6DirectYDecomposition X,
          dr6ActualPhiGram (D := D) f p.val.1 p.val.2 ^ 2) := by
  classical
  let H (p : DR6DirectYDecomposition X) :=
    dr6ActualPhiGram (D := D) f p.val.1 p.val.2
  have hpair := dr6_actual_f1_weight_sum_le_gram f X hsupport
  have hOuterCount : Fintype.card (DR6DirectYDecomposition X) ≤
      2^(4 * D * D) := by
    calc
      Fintype.card (DR6DirectYDecomposition X) ≤ 2^(X.rank * X.rank) :=
        dr6_y_decomposition_card_le_pow X
      _ ≤ 2^(4 * D * D) := by
        have hexp : X.rank * X.rank ≤ 4 * D * D := by
          calc
            X.rank * X.rank ≤ (2 * D) * (2 * D) := Nat.mul_le_mul hXrank hXrank
            _ = 4 * D * D := by ring
        exact Nat.pow_le_pow_right (by decide) hexp
  have hgram : (∑ p : DR6DirectYDecomposition X, H p) ^ 2 ≤
      (Fintype.card (DR6DirectYDecomposition X) : Real) *
        (∑ p : DR6DirectYDecomposition X, H p ^ 2) := by
    simpa [H, one_pow] using
      (Finset.sum_mul_sq_le_sq_mul_sq
        (Finset.univ : Finset (DR6DirectYDecomposition X))
        (fun _ => (1 : Real)) H)
  have hCardReal :
      (Fintype.card (DR6DirectYDecomposition X) : Real) ≤
        (2^(4 * D * D) : Real) := by exact_mod_cast hOuterCount
  have hHnonneg : 0 ≤ ∑ p : DR6DirectYDecomposition X, H p := by
    apply Finset.sum_nonneg
    intro p hp
    exact dr6_actual_phi_gram_nonneg f p.val.1 p.val.2
  have hHSqBound : (∑ p : DR6DirectYDecomposition X, H p) ^ 2 ≤
      (2^(4 * D * D) : Real) *
        (∑ p : DR6DirectYDecomposition X, H p ^ 2) := by
    calc
      _ ≤ (Fintype.card (DR6DirectYDecomposition X) : Real) *
            (∑ p : DR6DirectYDecomposition X, H p ^ 2) := hgram
      _ ≤ (2^(4 * D * D) : Real) *
            (∑ p : DR6DirectYDecomposition X, H p ^ 2) :=
        mul_le_mul_of_nonneg_right hCardReal
          (Finset.sum_nonneg fun p hp => sq_nonneg (H p))
  have hPairNonneg : 0 ≤ ∑ p : dr6ActualF1Pairs X,
      norm (complexFourierCoeff f p.val.1) *
        norm (complexFourierCoeff f p.val.2) := by
    apply Finset.sum_nonneg
    intro p hp
    exact mul_nonneg (norm_nonneg _) (norm_nonneg _)
  have hP := (sq_le_sq₀ hPairNonneg hHnonneg).2 hpair
  simpa [H] using hP.trans hHSqBound

/-- Summing the manuscript's F1 energy over every output costs only the
outer predecessor count.  Outputs outside rank `2D` have zero F1 mass by
Fourier support; the remaining `(X,A,B)` indices inject into ordered pairs
`(A,B)`, so the Gram Frobenius bound is used globally only once. -/
theorem dr6_actual_f1_total_energy_le_parseval {n d D : Nat}
    (f : BinaryMatrix n d → Complex)
    (hsupport : ComplexFourierSupportedThrough D f) :
    (∑ X : BinaryMatrix n d,
      (∑ p : dr6ActualF1Pairs X,
        norm (complexFourierCoeff f p.val.1) *
          norm (complexFourierCoeff f p.val.2)) ^ 2) ≤
      (2^(4 * D * D) : Real) *
        (dr6ActualPhiCoefficientMass (D := D) f) ^ 2 := by
  classical
  let H (X : BinaryMatrix n d) (p : DR6DirectYDecomposition X) :=
    dr6ActualPhiGram (D := D) f p.val.1 p.val.2
  have hpoint (X : BinaryMatrix n d) :
      (∑ p : dr6ActualF1Pairs X,
        norm (complexFourierCoeff f p.val.1) *
          norm (complexFourierCoeff f p.val.2)) ^ 2 ≤
      (2^(4 * D * D) : Real) *
        (∑ p : DR6DirectYDecomposition X, (H X p) ^ 2) := by
    by_cases hX : X.rank ≤ 2 * D
    · exact dr6_actual_f1_energy_at_X_le f X hsupport hX
    · have hzero :
          ∑ p : dr6ActualF1Pairs X,
            norm (complexFourierCoeff f p.val.1) *
              norm (complexFourierCoeff f p.val.2) = 0 := by
        apply Finset.sum_eq_zero
        intro p hp
        by_cases hY : p.val.1.rank ≤ D
        · by_cases hZ : p.val.2.rank ≤ D
          · have hX' : X.rank ≤ 2 * D := by
             calc
                X.rank = (p.val.1 + p.val.2).rank :=
                  congrArg (fun M : BinaryMatrix n d => M.rank)
                    p.property.1.symm
                _ ≤ p.val.1.rank + p.val.2.rank :=
                  ActualFiniteDegreeFourierProduct.binaryMatrix_rank_add_le
                    p.val.1 p.val.2
                _ ≤ D + D := Nat.add_le_add hY hZ
                _ = 2 * D := by omega
            exact False.elim (hX hX')
          · have hzeroY : complexFourierCoeff f p.val.2 = 0 :=
              hsupport p.val.2 (Nat.lt_of_not_ge hZ)
            simp [hzeroY]
        · have hzeroY : complexFourierCoeff f p.val.1 = 0 :=
            hsupport p.val.1 (Nat.lt_of_not_ge hY)
          simp [hzeroY]
      simp [hzero]
      exact Finset.sum_nonneg fun p hp => sq_nonneg (H X p)
  have hsumPoint :
      (∑ X : BinaryMatrix n d,
        (∑ p : dr6ActualF1Pairs X,
          norm (complexFourierCoeff f p.val.1) *
            norm (complexFourierCoeff f p.val.2)) ^ 2) ≤
      (2^(4 * D * D) : Real) *
        ∑ X : BinaryMatrix n d,
          ∑ p : DR6DirectYDecomposition X, (H X p) ^ 2 := by
    calc
      _ ≤ ∑ X : BinaryMatrix n d,
            (2^(4 * D * D) : Real) *
              ∑ p : DR6DirectYDecomposition X, (H X p) ^ 2 :=
          Finset.sum_le_sum fun X hX => hpoint X
      _ = _ := by rw [← Finset.mul_sum]
  let Q := Σ X : BinaryMatrix n d, DR6DirectYDecomposition X
  let e : Q → BinaryMatrix n d × BinaryMatrix n d :=
    fun q => q.2.val
  have he : Function.Injective e := by
    rintro ⟨X, p⟩ ⟨X', p'⟩ hqr
    have hpair : p.val = p'.val :=
      hqr
    have hX : X = X' := by
      calc
        X = p.val.1 + p.val.2 := p.property.1
        _ = p'.val.1 + p'.val.2 := by rw [hpair]
        _ = X' := p'.property.1.symm
    subst X'
    have hp : p = p' := Subtype.ext hpair
    subst p'
    rfl
  have hSigma :
      (∑ q : Q, (H q.1 q.2) ^ 2) =
        ∑ X : BinaryMatrix n d,
          ∑ p : DR6DirectYDecomposition X, (H X p) ^ 2 :=
    Fintype.sum_sigma (fun q : Q => (H q.1 q.2) ^ 2)
  have haggregate :
      (∑ X : BinaryMatrix n d,
        ∑ p : DR6DirectYDecomposition X, (H X p) ^ 2) ≤
      ∑ q : BinaryMatrix n d × BinaryMatrix n d,
        dr6ActualPhiGram (D := D) f q.1 q.2 ^ 2 := by
    rw [← hSigma]
    apply Finset.sum_le_sum_of_injOn
      (s := Finset.univ) (t := Finset.univ) e
    · intro p hp q hq hpq
      exact he hpq
    · intro q hq
      exact Finset.mem_univ q
    · intro q hq
      rfl
    · intro q hq hnot
      exact sq_nonneg (dr6ActualPhiGram (D := D) f q.1 q.2)
  calc
    _ ≤ (2^(4 * D * D) : Real) *
          ∑ X : BinaryMatrix n d,
            ∑ p : DR6DirectYDecomposition X, (H X p) ^ 2 := hsumPoint
    _ ≤ (2^(4 * D * D) : Real) *
          ∑ q : BinaryMatrix n d × BinaryMatrix n d,
            dr6ActualPhiGram (D := D) f q.1 q.2 ^ 2 := by
          exact mul_le_mul_of_nonneg_left haggregate (by positivity)
    _ ≤ (2^(4 * D * D) : Real) *
          dr6ActualPhiCoefficientMass (D := D) f ^ 2 := by
          have hFrob := dr6_actual_phi_gram_frobenius_le_mass f
          rw [Fintype.sum_prod_type] at hFrob
          exact mul_le_mul_of_nonneg_left hFrob (by positivity)

/-- The exact complex-input F1 moment estimate consumed by DR6: the whole
ordinary-selector F1 fourth-moment contribution is at most
`2^(6D^2) ||f||_2^4`, with only the manuscript Fourier-support premise. -/
theorem dr6_actual_f1_total_energy_le {n d D : Nat}
    (f : BinaryMatrix n d → Complex)
    (hsupport : ComplexFourierSupportedThrough D f) :
    (∑ X : BinaryMatrix n d,
      (∑ p : dr6ActualF1Pairs X,
        norm (complexFourierCoeff f p.val.1) *
          norm (complexFourierCoeff f p.val.2)) ^ 2) ≤
      (2^(6 * D * D) : Real) *
        (uniformMean (fun M => Complex.normSq (f M))) ^ 2 := by
  classical
  have hbase := dr6_actual_f1_total_energy_le_parseval f hsupport
  have hmass := dr6_actual_phi_coefficient_mass_le_parseval f hsupport
  have hmass0 : 0 ≤ dr6ActualPhiCoefficientMass (D := D) f := by
    unfold dr6ActualPhiCoefficientMass dr6ActualPhiRowEnergy
    apply Finset.sum_nonneg
    intro A hA
    apply Finset.sum_nonneg
    intro C hC
    exact sq_nonneg _
  have hnorm0 : 0 ≤
      (2^(D * D) : Real) * uniformMean (fun M => Complex.normSq (f M)) :=
    le_trans hmass0 hmass
  have hsq := (sq_le_sq₀ hmass0 hnorm0).2 hmass
  have hpow : (2 : Real)^(4 * D * D) * ((2 : Real)^(D * D))^2 =
      (2 : Real)^(6 * D * D) := by
    rw [← pow_mul, ← pow_add]
    congr 1 <;> ring
  calc
    _ ≤ (2^(4 * D * D) : Real) *
          dr6ActualPhiCoefficientMass (D := D) f ^ 2 := hbase
    _ ≤ (2^(4 * D * D) : Real) *
          ((2^(D * D) : Real) *
            uniformMean (fun M => Complex.normSq (f M))) ^ 2 :=
          mul_le_mul_of_nonneg_left hsq (by positivity)
    _ = (2^(6 * D * D) : Real) *
          (uniformMean (fun M => Complex.normSq (f M))) ^ 2 := by
          rw [mul_pow, ← hpow]
          ring

end
end PvNP.RealizableHardness.ActualBinaryMatrixHC46DR6SignMoments
