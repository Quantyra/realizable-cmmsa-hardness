import PvNP.RealizableHardness.ActualBinaryMatrixHC46DR6Incidence
import PvNP.RealizableHardness.ActualBinaryMatrixHC46A7HybridW6Transport

/-! T1 exact-transfer structures on the actual finite F2 carriers.

The index triple is represented by C <= A, the quotient subspace H/B <= W/B,
and the manuscript isomorphism H/B ~= A/C.  The actual ambient H is recovered
as the preimage of H/B under W -> W/B.  This representation keeps the
quotient carriers explicit; it does not identify the quotient isomorphism,
its pullback H -> V/C, and the original map q_C Y|H.
-/

namespace PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer

open scoped BigOperators

set_option autoImplicit false
noncomputable section
attribute [local instance] Classical.propDecidable

open PvNP.RealizableHardness.ActualBinaryMatrixHC46A7WeightedPredecessor
open PvNP.RealizableHardness.BinaryMatrixFourier
open PvNP.RealizableHardness.ActualBinaryMatrixHC46DR6Convolution

private abbrev F := ZMod 2
private abbrev V (d : Nat) := Fin d -> F
private abbrev W (n : Nat) := Fin n -> F

/-- A T1 index triple. `K` is the actual quotient subspace H/B in W/B;
`Xbar` has the manuscript direction H/B ~= A/C. -/
structure T1IndexTriple {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n)) where
  C : Submodule F A
  K : Submodule F (W n ⧸ B)
  Xbar : K ≃ₗ[F] (A ⧸ C)

/-- Encode the triple by theta : A -> W/B, with the quotient map first,
then Xbar inverse, then the inclusion H/B -> W/B. -/
def t1TripleToMap {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) : A →ₗ[F] (W n ⧸ B) :=
  t.K.subtype.comp (t.Xbar.symm.toLinearMap.comp t.C.mkQ)

/-- Build the quotient triple associated to theta using its kernel and range.
C is the kernel subspace inside A; its ambient image in V is induced by A's
subtype. K is im(theta)=H/B. -/
def t1MapToTriple {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (theta : A →ₗ[F] (W n ⧸ B)) : T1IndexTriple A B where
  C := LinearMap.ker theta
  K := LinearMap.range theta
  Xbar := theta.quotKerEquivRange.symm

/-- The triple-to-map-to-triple direction recovers theta on every vector. -/
theorem t1TripleToMap_mapToTriple {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (theta : A →ₗ[F] (W n ⧸ B)) :
    t1TripleToMap (t1MapToTriple theta) = theta := by
  classical
  ext a
  change ((theta.quotKerEquivRange (Submodule.Quotient.mk a) :
    LinearMap.range theta) : W n ⧸ B) = theta a
  rw [LinearMap.quotKerEquivRange_apply_mk]

/-- The map encoded by a triple has exactly C as its kernel. -/
theorem t1TripleToMap_ker {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) :
    LinearMap.ker (t1TripleToMap t) = t.C := by
  ext a
  simp [t1TripleToMap]

/-- The map encoded by a triple has exactly K=H/B as its range. -/
theorem t1TripleToMap_range {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) :
    LinearMap.range (t1TripleToMap t) = t.K := by
  ext y
  constructor
  · rintro ⟨a, rfl⟩
    exact (t.Xbar.symm (t.C.mkQ a)).property
  · intro hy
    obtain ⟨a, ha⟩ := Submodule.mkQ_surjective t.C (t.Xbar ⟨y, hy⟩)
    have heq : ((t.Xbar.symm (t.C.mkQ a) : t.K) : W n ⧸ B) = y := by
      change ((t.Xbar.symm (t.C.mkQ a) : t.K) : W n ⧸ B) = y
      rw [ha]
      simp
    exact ⟨a, heq⟩

/-- Reconstructing the index triple from its encoded map recovers C and K. -/
theorem t1MapToTriple_CK_roundTrip {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) :
    (t1MapToTriple (t1TripleToMap t)).C = t.C ∧
      (t1MapToTriple (t1TripleToMap t)).K = t.K := by
  constructor
  · exact t1TripleToMap_ker t
  · exact t1TripleToMap_range t

/-- The map encoding is injective: its kernel, range, and the induced
quotient isomorphism recover all three fields of the index triple. -/
theorem t1TripleToMap_injective {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    {t s : T1IndexTriple A B}
    (h : t1TripleToMap t = t1TripleToMap s) : t = s := by
  cases t with
  | mk tC tK tX =>
    cases s with
    | mk sC sK sX =>
      have hC : tC = sC := by
        calc
          tC = LinearMap.ker (t1TripleToMap ⟨tC, tK, tX⟩) :=
            (t1TripleToMap_ker ⟨tC, tK, tX⟩).symm
          _ = LinearMap.ker (t1TripleToMap ⟨sC, sK, sX⟩) := congrArg LinearMap.ker h
          _ = sC := t1TripleToMap_ker ⟨sC, sK, sX⟩
      subst sC
      have hK : tK = sK := by
        calc
          tK = LinearMap.range (t1TripleToMap ⟨tC, tK, tX⟩) :=
            (t1TripleToMap_range ⟨tC, tK, tX⟩).symm
          _ = LinearMap.range (t1TripleToMap ⟨tC, sK, sX⟩) := congrArg LinearMap.range h
          _ = sK := t1TripleToMap_range ⟨tC, sK, sX⟩
      subst sK
      have hX : tX = sX := by
        apply LinearEquiv.ext
        intro k
        obtain ⟨a, ha⟩ := Submodule.mkQ_surjective tC (tX k)
        have hback : tX.symm (tC.mkQ a) = sX.symm (tC.mkQ a) := by
          apply Subtype.ext
          exact DFunLike.congr_fun h a
        have hvalue := congrArg sX.toLinearMap hback
        simpa [ha] using hvalue.symm
      subst sX
      rfl

/-- Actual index triples and maps A -> W/B are equivalent in both
directions, with the two inverse laws proved above. -/
noncomputable def t1TripleEquiv {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n)) :
    T1IndexTriple A B ≃ (A →ₗ[F] (W n ⧸ B)) where
  toFun := t1TripleToMap
  invFun := t1MapToTriple
  left_inv t := by
    apply t1TripleToMap_injective
    exact t1TripleToMap_mapToTriple A B (t1TripleToMap t)
  right_inv theta := t1TripleToMap_mapToTriple A B theta

noncomputable instance t1TripleFintype {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n)) :
    Fintype (T1IndexTriple A B) := by
  classical
  letI : Fintype A := Fintype.ofFinite A
  letI : Fintype (W n ⧸ B) := Fintype.ofFinite _
  letI : Fintype (A →ₗ[F] (W n ⧸ B)) := FunLike.fintype _
  exact Fintype.ofEquiv _ (t1TripleEquiv A B).symm

/-- The exact cardinality of all T1 index triples, with zero-dimensional
cases included. -/
set_option maxHeartbeats 2000000 in
theorem t1Triple_card {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n)) :
    Fintype.card (T1IndexTriple A B) =
      2 ^ (Module.finrank F A * Module.finrank F (W n ⧸ B)) := by
  classical
  letI : Fintype A := Fintype.ofFinite A
  letI : Fintype (W n ⧸ B) := Fintype.ofFinite _
  letI : Fintype (A →ₗ[F] (W n ⧸ B)) := FunLike.fintype _
  let e : T1IndexTriple A B ≃ (A →ₗ[F] (W n ⧸ B)) :=
    t1TripleEquiv A B
  rw [Fintype.card_congr e]
  exact w6_card_linearMap_binary

/-- Recover the actual ambient H from its quotient subspace K=H/B. -/
def t1AmbientH {n : Nat} {B : Submodule F (W n)}
    (K : Submodule F (W n ⧸ B)) : Submodule F (W n) :=
  K.comap (Submodule.mkQ B)

/-- The quotient map sends the recovered H onto the original quotient
subspace K. -/
theorem t1AmbientH_quotientRange {n : Nat}
    (B : Submodule F (W n)) (K : Submodule F (W n ⧸ B)) :
    LinearMap.range
      ((Submodule.mkQ B).comp (t1AmbientH K).subtype) = K := by
  ext x
  constructor
  · rintro ⟨w, rfl⟩
    exact w.2
  · intro hx
    obtain ⟨w, hw⟩ := Submodule.mkQ_surjective B x
    have hwmem : w ∈ t1AmbientH K := by
      change Submodule.mkQ B w ∈ K
      rw [hw]
      exact hx
    exact ⟨⟨w, hwmem⟩, hw⟩

/-- Conversely, every ambient H containing B is recovered exactly from its
quotient image K=q_B(H). -/
theorem t1AmbientH_of_quotientRange {n : Nat}
    (B H : Submodule F (W n)) (hBH : B ≤ H) :
    t1AmbientH (LinearMap.range ((Submodule.mkQ B).comp H.subtype)) = H := by
  ext w
  change Submodule.mkQ B w ∈
      LinearMap.range ((Submodule.mkQ B).comp H.subtype) ↔ w ∈ H
  constructor
  · rintro ⟨h, hq⟩
    have hdiff : w - h ∈ B :=
      (Submodule.Quotient.eq B).mp hq.symm
    have hdecomp : w = (w - h) + h := by abel
    rw [hdecomp]
    exact H.add_mem (hBH hdiff) h.property
  · intro hw
    exact ⟨⟨w, hw⟩, rfl⟩

/-- The recovered ambient H contains B, including when K is zero. -/
theorem t1AmbientH_containsB {n : Nat}
    (B : Submodule F (W n)) (K : Submodule F (W n ⧸ B)) :
    B ≤ t1AmbientH K := by
  intro b hb
  change Submodule.mkQ B b ∈ K
  have hzero : Submodule.mkQ B b = 0 := by
    rw [Submodule.mkQ_apply]
    exact (Submodule.Quotient.mk_eq_zero B).mpr hb
  rw [hzero]
  exact K.zero_mem

/-- Quotienting the recovered H by its copy of B gives exactly K. -/
noncomputable def t1AmbientHQuotientEquiv {n : Nat}
    (B : Submodule F (W n)) (K : Submodule F (W n ⧸ B)) :
    (t1AmbientH K ⧸ B.comap (t1AmbientH K).subtype) ≃ₗ[F] K := by
  let H := t1AmbientH K
  let qH : H →ₗ[F] (W n ⧸ B) := (Submodule.mkQ B).comp H.subtype
  have hker : LinearMap.ker qH = B.comap H.subtype := by
    ext h
    change Submodule.mkQ B (H.subtype h) = 0 ↔ H.subtype h ∈ B
    rw [Submodule.mkQ_apply]
    exact (Submodule.Quotient.mk_eq_zero B)
  have hrange : LinearMap.range qH = K := by
    simpa [qH, H] using t1AmbientH_quotientRange B K
  let e0 := qH.quotKerEquivRange
  let eqQuot : (H ⧸ B.comap H.subtype) ≃ₗ[F] (H ⧸ LinearMap.ker qH) :=
    Submodule.quotEquivOfEq _ _ hker.symm
  exact eqQuot.trans (e0.trans (LinearEquiv.ofEq _ _ hrange))

/-- Embed the internal C <= A as the actual manuscript subspace of V. -/
def t1AmbientC {d : Nat} {A : Submodule F (V d)}
    (C : Submodule F A) : Submodule F (V d) := C.map A.subtype

/-- The embedded C remains a subspace of the actual A. -/
theorem t1AmbientC_le_A {d : Nat} {A : Submodule F (V d)}
    (C : Submodule F A) : t1AmbientC C ≤ A := by
  rintro v ⟨a, ha, rfl⟩
  exact a.property

/-- The canonical inclusion of the internal quotient A/C into the actual
ambient quotient V/(C.map A.subtype). -/
noncomputable def t1AQuotientToAmbient {d : Nat}
    {A : Submodule F (V d)} (C : Submodule F A) :
    (A ⧸ C) →ₗ[F] (V d ⧸ t1AmbientC C) :=
  C.liftQ
    ((Submodule.mkQ (t1AmbientC C)).comp A.subtype)
    (by
      intro a ha
      change Submodule.mkQ (t1AmbientC C) (A.subtype a) = 0
      apply (Submodule.Quotient.mk_eq_zero (t1AmbientC C)).mpr
      exact ⟨a, ha, rfl⟩)

/-- The pullback map Xtilde:H -> V/C on the actual H and ambient quotient.
It is built from H/B=K, the isomorphism Xbar:K ~= A/C, and the canonical
map A/C -> V/C. -/
noncomputable def t1PullbackMap {n d : Nat}
    {A : Submodule F (V d)} {B : Submodule F (W n)}
    (t : T1IndexTriple A B) :
    t1AmbientH t.K →ₗ[F] (V d ⧸ t1AmbientC t.C) :=
  (t1AQuotientToAmbient t.C).comp
    (t.Xbar.toLinearMap.comp
      ((t1AmbientHQuotientEquiv B t.K).toLinearMap.comp
        (Submodule.mkQ (B.comap (t1AmbientH t.K).subtype))))

/-- The original restricted frequency R=q_C o Y|H; this is not Xtilde. -/
def t1OriginalRestriction {n d : Nat}
    (Y : BinaryMatrix n d)
    (C : Submodule F (V d)) (H : Submodule F (W n)) :
    H →ₗ[F] (V d ⧸ C) :=
  (Submodule.mkQ C).comp (Y.transpose.toLin'.comp H.subtype)

/-- Rank-poset relation R = Xtilde + a complementary displacement. -/
def t1RankPrecedes {U Z : Type*} [AddCommGroup U] [Module F U]
    [AddCommGroup Z] [Module F Z]
    (X R : U →ₗ[F] Z) : Prop :=
  Module.finrank F (LinearMap.range R) =
    Module.finrank F (LinearMap.range X) +
      Module.finrank F (LinearMap.range (R - X))

/-- A frequency activates a triple exactly when it passes the hybrid selector
and Xtilde is a rank-additive predecessor of the actual R map. -/
def t1ActiveTriple {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Y : BinaryMatrix n d) (t : T1IndexTriple A B) : Prop :=
  let C := t1AmbientC t.C
  let H := t1AmbientH t.K
  PvNP.RealizableHardness.BinaryMatrixNestedSelectorA1.Selected
      C H Y.transpose.toLin' ∧
    t1RankPrecedes (t1PullbackMap t) (t1OriginalRestriction Y C H)

/-- For an ordinarily selected frequency, descend the inverse of Y on A
through W/ker(Y), then through W/B. The kernel inclusion ker(Y)<=B makes the
second quotient map well defined. -/
noncomputable def t1SelectedTheta {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Y : BinaryMatrix n d)
    (hY : DR6OrdinarySelected A B Y) : A →ₗ[F] (W n ⧸ B) := by
  let L := Y.transpose.toLin'
  let qbar := (LinearMap.ker L).mapQ B LinearMap.id hY.2
  exact qbar.comp
    ((L.quotKerEquivRange).symm.toLinearMap.comp
      (Submodule.inclusion hY.1))

/-- The descended map theta records the actual B-coset of every preimage in
Y^(-1)(A); this representative formula is the bridge for C and H recovery. -/
theorem t1SelectedTheta_on_preimage {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Y : BinaryMatrix n d)
    (hY : DR6OrdinarySelected A B Y)
    (w : W n) (hw : Y.transpose.toLin' w ∈ A) :
    t1SelectedTheta A B Y hY ⟨Y.transpose.toLin' w, hw⟩ =
      Submodule.mkQ B w := by
  let L := Y.transpose.toLin'
  let e := L.quotKerEquivRange
  let y : LinearMap.range L := ⟨L w, ⟨w, rfl⟩⟩
  have hquot : e.symm y = Submodule.Quotient.mk w := by
    apply e.injective
    rw [LinearMap.quotKerEquivRange_apply_mk]
    rfl
  rw [hquot]
  change (LinearMap.ker L).mapQ B LinearMap.id hY.2
      (Submodule.Quotient.mk w) = Submodule.mkQ B w
  rw [← LinearMap.comp_apply, Submodule.mapQ_mkQ, LinearMap.comp_apply]

/-- The selected ordinary frequency's index triple is obtained from its
descended theta by the proved inverse map-to-triple direction. -/
noncomputable def t1SelectedTriple {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Y : BinaryMatrix n d) (hY : DR6OrdinarySelected A B Y) :
    T1IndexTriple A B :=
  t1MapToTriple (t1SelectedTheta A B Y hY)

/-- Encoding the selected triple recovers its ordinary theta exactly. -/
theorem t1SelectedTriple_toMap {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Y : BinaryMatrix n d) (hY : DR6OrdinarySelected A B Y) :
    t1TripleToMap (t1SelectedTriple A B Y hY) =
      t1SelectedTheta A B Y hY := by
  exact t1TripleToMap_mapToTriple A B (t1SelectedTheta A B Y hY)

/-- The kernel of the selected theta is precisely the selected image part
Y(B) intersected with A, represented internally as a subspace of A. -/
theorem t1SelectedTheta_ker {n d : Nat}
    (A : Submodule F (V d)) (B : Submodule F (W n))
    (Y : BinaryMatrix n d) (hY : DR6OrdinarySelected A B Y) :
    LinearMap.ker (t1SelectedTheta A B Y hY) =
      (LinearMap.range (Y.transpose.toLin'.comp B.subtype)).comap A.subtype := by
  ext a
  change t1SelectedTheta A B Y hY a = 0 ↔
    (a : V d) ∈ LinearMap.range (Y.transpose.toLin'.comp B.subtype)
  constructor
  · intro hzero
    obtain ⟨w, hw⟩ := hY.1 a.property
    have heval := t1SelectedTheta_on_preimage A B Y hY w (by simpa [hw])
    have hwB : w ∈ B := by
      apply (Submodule.Quotient.mk_eq_zero B).mp
      rw [← heval]
      exact hzero
    refine ⟨⟨w, hwB⟩, by simpa using hw⟩
  · rintro ⟨b, hb⟩
    have haeq : (⟨Y.transpose.toLin' (B.subtype b), by
        rw [hb]
        exact a.property⟩ : A) = a := by
      apply Subtype.ext
      exact hb
    have heval := t1SelectedTheta_on_preimage A B Y hY (B.subtype b) (by
      change Y.transpose.toLin' (B.subtype b) ∈ A
      rw [hb]
      exact a.property)
    rw [← haeq, heval]
    apply (Submodule.Quotient.mk_eq_zero B).mpr
    exact b.property

end
end PvNP.RealizableHardness.ActualBinaryMatrixHC46A7T1Transfer
