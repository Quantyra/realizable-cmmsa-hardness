#!/usr/bin/env bash
set -u

RUN=gcp_actual_source_star_law_s7_20260924T133651Z
HOME_DIR=/home/dfredriksen_quantyra_org
BASE="$HOME_DIR/mz24-fixed-rho-de048da"
IN="$HOME_DIR/${RUN}_incoming"
WT="$HOME_DIR/${RUN}_worktree"
EV="$HOME_DIR/$RUN"
BUNDLE="$IN/accepted-complete-history.bundle"
COMMIT=dbf70d9e922b4f77af98a1bc8090f775c0d31ff6
BUNDLE_SHA=031cb8ac127101cf819dbbcfb0c2422fea452070d10de107826c45698ca8ce67
MAIN_SHA=dc4ec18dcf630a02207318690d64cda672e0dacbc72dcd34c438baaaf883da11
CHECKS_SHA=51e1d894131e0d16beed18f8386ca65b9b7896bb2647fd84fc981db356b1088e
TOOLCHAIN="$HOME_DIR/.elan/toolchains/leanprover--lean4---v4.34.0-rc2/bin"
LAKE="$TOOLCHAIN/lake"
LEAN="$TOOLCHAIN/lean"
MAIN=PvNP.RealizableHardness.ActualSourceStarLaw
CHECKS=PvNP.RealizableHardness.ActualSourceStarLawChecks
MAIN_SRC=lean/PvNP/RealizableHardness/ActualSourceStarLaw.lean
CHECKS_SRC=lean/PvNP/RealizableHardness/ActualSourceStarLawChecks.lean
REL=PvNP/RealizableHardness
ACCEPTED="$HOME_DIR/${RUN}_accepted_lean"
DIRECT_WORK="$HOME_DIR/${RUN}_direct_lean"
REPLAY_WORK="$HOME_DIR/${RUN}_replay_lean"
DIRECT="$EV/direct-olean"
REPLAY="$EV/replay-olean"

make_manifest() {
  (
    cd "$EV" || exit 1
    find . -type f ! -name EVIDENCE.sha256 -print0 | sort -z |
      xargs -0 sha256sum > EVIDENCE.sha256
  )
}

scan_errors() {
  {
    printf 'ANCHORED_ERRORS_BEGIN\n'
    grep -nE '(^|: )(error:|panic:)|^[^:]+:[0-9]+:[0-9]+: error:' \
      "$EV"/0[5-9]_*.log "$EV"/1[0-4]_*.log 2>/dev/null || true
    printf 'ANCHORED_ERRORS_END\n'
  } > "$EV/16_anchored_errors.log"
}

parse_axioms() {
  awk '
    function trim(s) {
      sub(/^[[:space:]]+/, "", s)
      sub(/[[:space:]]+$/, "", s)
      return s
    }
    function fail(message) {
      print "AXIOM_PARSE_ERROR=" message > "/dev/stderr"
      bad = 1
    }
    function validate(    text, count, items, i, token, normalized, seen) {
      text = trim(buffer)
      normalized = ""
      delete seen
      if (text != "") {
        count = split(text, items, ",")
        for (i = 1; i <= count; i++) {
          token = trim(items[i])
          if (token != "propext" && token != "Classical.choice" && token != "Quot.sound")
            fail("unexpected axiom: " token)
          if (seen[token]++)
            fail("duplicate axiom: " token)
          normalized = normalized (i == 1 ? "" : ", ") token
        }
      }
      complete++
      printf "AXIOM_REPORT_%d=[%s]\n", complete, normalized
    }
    {
      text = $0
      marker = "depends on axioms:"
      if (!in_report) {
        start = index(text, marker)
        if (!start)
          next
        reports++
        text = substr(text, start + length(marker))
        opening = index(text, "[")
        if (!opening) {
          fail("missing opening bracket in report " reports)
          next
        }
        text = substr(text, opening + 1)
        buffer = ""
        in_report = 1
      } else if (index(text, marker)) {
        fail("nested report before closing bracket")
      }
      closing = index(text, "]")
      if (closing) {
        buffer = buffer " " substr(text, 1, closing - 1)
        tail = trim(substr(text, closing + 1))
        if (tail != "")
          fail("trailing text after report: " tail)
        validate()
        in_report = 0
      } else {
        buffer = buffer " " text
      }
    }
    END {
      if (in_report)
        fail("unterminated report")
      if (reports != 1)
        fail("expected 1 report, found " reports)
      if (complete != 1)
        fail("expected 1 complete report, found " complete)
      exit bad
    }
  ' "$1"
}

finish_failure() {
  rc="$1"
  stage="$2"
  scan_errors
  {
    printf 'RESULT=FAIL\nFAILED_STAGE=%s\nEXIT_CODE=%s\n' "$stage" "$rc"
    printf 'FAILURE_CLASS=%s\n' "${3-HARNESS}"
    printf 'WORKTREE_HEAD=%s\n' "$(git -C "$WT" rev-parse HEAD 2>/dev/null || printf unavailable)"
  } > "$EV/OUTCOME.txt"
  make_manifest
  exit "$rc"
}

netrun() {
  sudo -n env "LEAN_PATH=${LEAN_PATH-}" unshare -n -- "$@"
}

test ! -e "$EV" || exit 21
test ! -e "$WT" || exit 22
test ! -e "$ACCEPTED" || exit 23
test ! -e "$DIRECT_WORK" || exit 24
test ! -e "$REPLAY_WORK" || exit 25
mkdir -p "$EV" "$DIRECT/$REL" "$REPLAY/$REL" || exit 26
cp "$IN/driver.sh" "$EV/driver.sh" || finish_failure 27 preserve_driver
cp "$BUNDLE" "$EV/accepted-complete-history.bundle" || finish_failure 28 preserve_bundle

{
  printf 'RUN=%s\nUTC=%s\n' "$RUN" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  printf 'BASE=%s\nWORKTREE=%s\nEXPECTED_COMMIT=%s\n' "$BASE" "$WT" "$COMMIT"
  printf 'BASE_HEAD=%s\n' "$(git -C "$BASE" rev-parse HEAD)"
  printf 'BASE_STATUS_BEGIN\n'
  git -C "$BASE" status --short
  printf 'BASE_STATUS_END\nTOOLCHAIN_FILE=' && cat "$BASE/lean-toolchain"
  (cd "$BASE" && "$LAKE" --old env lean --version)
  (cd "$BASE" && "$LAKE" --version)
  printf 'NETWORK_NAMESPACE_BEGIN\n'
  network_rc=0
  sudo -n unshare -n -- sh -c 'printf "NETNS_OK=1\n"; cat /proc/net/route' || network_rc=$?
  printf 'NETWORK_NAMESPACE_END\nBASE_MANIFEST_HASHES_BEGIN\n'
  sha256sum "$BASE/lake-manifest.json" "$BASE/lakefile.toml" "$BASE/lean-toolchain"
  printf 'BASE_MANIFEST_HASHES_END\nPACKAGE_REVISIONS_BEGIN\n'
  for package in "$BASE"/.lake/packages/*; do
    test -e "$package" || continue
    printf '%s ' "$(basename "$package")"
    git -C "$package" rev-parse HEAD
  done
  printf 'PACKAGE_REVISIONS_END\n'
  test "$network_rc" -eq 0
} > "$EV/01_preflight.log" 2>&1 || finish_failure 29 preflight
grep -q 'Lean (version 4.34.0-rc2' "$EV/01_preflight.log" || finish_failure 30 lean_version

actual_bundle_sha=$(sha256sum "$BUNDLE" | cut -d' ' -f1)
{
  printf 'EXPECTED_BUNDLE_SHA256=%s\nACTUAL_BUNDLE_SHA256=%s\n' "$BUNDLE_SHA" "$actual_bundle_sha"
  git -C "$BASE" bundle verify "$BUNDLE"
} > "$EV/02_bundle_verify.log" 2>&1 || finish_failure 31 bundle_verify
test "$actual_bundle_sha" = "$BUNDLE_SHA" || finish_failure 32 bundle_hash

git clone "$BUNDLE" "$WT" > "$EV/03_checkout_setup.log" 2>&1 || finish_failure 33 clone
{
  git -C "$WT" checkout --detach "$COMMIT"
  mkdir -p "$WT/.lake"
  ln -s "$BASE/.lake/packages" "$WT/.lake/packages"
  ln -s "$BASE/.lake/build" "$WT/.lake/build"
  cp "$IN/ActualSourceStarLaw.lean" "$WT/$MAIN_SRC"
  cp "$IN/ActualSourceStarLawChecks.lean" "$WT/$CHECKS_SRC"
} >> "$EV/03_checkout_setup.log" 2>&1 || finish_failure 34 checkout_overlay

{
  printf 'WORKTREE_HEAD=%s\n' "$(git -C "$WT" rev-parse HEAD)"
  printf 'WORKTREE_BRANCH=%s\n' "$(git -C "$WT" symbolic-ref -q --short HEAD || printf DETACHED)"
  printf 'WORKTREE_STATUS_BEGIN\n'
  git -C "$WT" status --short
  printf 'WORKTREE_STATUS_END\nOVERLAY_COUNT=2\nOVERLAYS_BEGIN\n%s\n%s\nOVERLAYS_END\n' "$MAIN_SRC" "$CHECKS_SRC"
  printf 'CACHE_LINKS_BEGIN\n'
  ls -ld "$WT/.lake/packages" "$WT/.lake/build"
  readlink -f "$WT/.lake/packages"
  readlink -f "$WT/.lake/build"
  printf 'CACHE_LINKS_END\nSOURCE_HASHES_BEGIN\n'
  sha256sum "$WT/$MAIN_SRC" "$WT/$CHECKS_SRC" "$WT/lean-toolchain" "$WT/lakefile.toml" "$WT/lake-manifest.json"
  printf 'SOURCE_HASHES_END\n'
} > "$EV/04_checkout_metadata.log" 2>&1 || finish_failure 35 checkout_metadata
test "$(git -C "$WT" rev-parse HEAD)" = "$COMMIT" || finish_failure 36 checkout_head
test -z "$(git -C "$WT" symbolic-ref -q HEAD)" || finish_failure 37 checkout_not_detached
test "$(git -C "$WT" status --short | wc -l)" -eq 2 || finish_failure 38 overlay_count
test "$(sha256sum "$WT/$MAIN_SRC" | cut -d' ' -f1)" = "$MAIN_SHA" || finish_failure 39 main_hash
test "$(sha256sum "$WT/$CHECKS_SRC" | cut -d' ' -f1)" = "$CHECKS_SHA" || finish_failure 40 checks_hash
test "$(readlink -f "$WT/.lake/packages")" = "$BASE/.lake/packages" || finish_failure 41 packages_link
test "$(readlink -f "$WT/.lake/build")" = "$BASE/.lake/build" || finish_failure 42 build_link
cp "$WT/$MAIN_SRC" "$EV/ActualSourceStarLaw.lean"
cp "$WT/$CHECKS_SRC" "$EV/ActualSourceStarLawChecks.lean"

cd "$WT" || finish_failure 43 worktree_cd
LEAN_PATH_BASE=$("$LAKE" --old env printenv LEAN_PATH) || finish_failure 44 lean_path

netrun "$LAKE" --old build \
  PvNP.RealizableHardness.GrassmannFlagPosterior \
  PvNP.RealizableHardness.ActualFiniteIncidenceSampling \
  PvNP.RealizableHardness.ActualBinaryGrassmannSamplingBounds --force \
  > "$EV/05_dependency_forced_build.log" 2>&1
dep_rc=$?
printf '%s\n' "$dep_rc" > "$EV/05_dependency_forced_build.rc"
test "$dep_rc" -eq 0 || finish_failure 45 dependency_forced_build THEOREM
mkdir -p "$ACCEPTED" || finish_failure 46 accepted_closure_mkdir
cp -a "$WT/.lake/build/lib/lean/." "$ACCEPTED/" || finish_failure 47 accepted_closure_copy
rm -f "$ACCEPTED/$REL/ActualSourceStarLaw.olean" "$ACCEPTED/$REL/ActualSourceStarLawChecks.olean"
{
  printf 'LEAN_PATH_BASE=%s\n' "$LEAN_PATH_BASE"
  printf 'ACCEPTED_OLEAN_COUNT=%s\n' "$(find "$ACCEPTED" -type f -name '*.olean' | wc -l)"
} > "$EV/06_dependency_closure.log" 2>&1 || finish_failure 48 dependency_closure_metadata

mkdir -p "$DIRECT_WORK" || finish_failure 49 direct_closure_mkdir
cp -a "$ACCEPTED/." "$DIRECT_WORK/" || finish_failure 50 direct_closure_copy
LEAN_PATH="$DIRECT_WORK:$LEAN_PATH_BASE" netrun "$LEAN" \
  -o "$DIRECT_WORK/$REL/ActualSourceStarLaw.olean" "$MAIN_SRC" \
  > "$EV/07_direct_main.log" 2>&1
main_rc=$?
printf '%s\n' "$main_rc" > "$EV/07_direct_main.rc"
test "$main_rc" -eq 0 || finish_failure 51 direct_main THEOREM
cp "$DIRECT_WORK/$REL/ActualSourceStarLaw.olean" "$DIRECT/$REL/"

LEAN_PATH="$DIRECT_WORK:$LEAN_PATH_BASE" netrun "$LEAN" \
  -o "$DIRECT_WORK/$REL/ActualSourceStarLawChecks.olean" "$CHECKS_SRC" \
  > "$EV/08_direct_checks.log" 2>&1
checks_rc=$?
printf '%s\n' "$checks_rc" > "$EV/08_direct_checks.rc"
test "$checks_rc" -eq 0 || finish_failure 52 direct_checks THEOREM
cp "$DIRECT_WORK/$REL/ActualSourceStarLawChecks.olean" "$DIRECT/$REL/"

netrun "$LAKE" --old build "$MAIN" "$CHECKS" --force > "$EV/09_combined_forced_build.log" 2>&1
combined_rc=$?
printf '%s\n' "$combined_rc" > "$EV/09_combined_forced_build.rc"
test "$combined_rc" -eq 0 || finish_failure 53 combined_forced_build THEOREM

mkdir -p "$REPLAY_WORK" || finish_failure 54 replay_closure_mkdir
cp -a "$ACCEPTED/." "$REPLAY_WORK/" || finish_failure 55 replay_closure_copy
LEAN_PATH="$REPLAY_WORK:$LEAN_PATH_BASE" netrun "$LEAN" \
  -o "$REPLAY_WORK/$REL/ActualSourceStarLaw.olean" "$MAIN_SRC" \
  > "$EV/10_replay_main.log" 2>&1
replay_main_rc=$?
printf '%s\n' "$replay_main_rc" > "$EV/10_replay_main.rc"
test "$replay_main_rc" -eq 0 || finish_failure 56 replay_main THEOREM
cp "$REPLAY_WORK/$REL/ActualSourceStarLaw.olean" "$REPLAY/$REL/"

LEAN_PATH="$REPLAY_WORK:$LEAN_PATH_BASE" netrun "$LEAN" \
  -o "$REPLAY_WORK/$REL/ActualSourceStarLawChecks.olean" "$CHECKS_SRC" \
  > "$EV/11_replay_checks.log" 2>&1
replay_checks_rc=$?
printf '%s\n' "$replay_checks_rc" > "$EV/11_replay_checks.rc"
test "$replay_checks_rc" -eq 0 || finish_failure 57 replay_checks THEOREM
cp "$REPLAY_WORK/$REL/ActualSourceStarLawChecks.olean" "$REPLAY/$REL/"

sha256sum \
  "$DIRECT/$REL/ActualSourceStarLaw.olean" \
  "$DIRECT/$REL/ActualSourceStarLawChecks.olean" \
  "$REPLAY/$REL/ActualSourceStarLaw.olean" \
  "$REPLAY/$REL/ActualSourceStarLawChecks.olean" \
  > "$EV/12_olean_hashes.log" 2>&1 || finish_failure 58 olean_hashes
test "$(sha256sum "$DIRECT/$REL/ActualSourceStarLaw.olean" | cut -d' ' -f1)" = \
  "$(sha256sum "$REPLAY/$REL/ActualSourceStarLaw.olean" | cut -d' ' -f1)" || finish_failure 59 unstable_main_olean THEOREM
test "$(sha256sum "$DIRECT/$REL/ActualSourceStarLawChecks.olean" | cut -d' ' -f1)" = \
  "$(sha256sum "$REPLAY/$REL/ActualSourceStarLawChecks.olean" | cut -d' ' -f1)" || finish_failure 60 unstable_checks_olean THEOREM

{
  printf 'CHECK_DIRECTIVES_BEGIN\n'
  grep -nE '^[[:space:]]*#(check|print[[:space:]]+axioms)[[:space:]]+' "$CHECKS_SRC"
  printf 'CHECK_DIRECTIVES_END\nCHECK_COUNT=%s\n' "$(grep -cE '^[[:space:]]*#check[[:space:]]+' "$CHECKS_SRC")"
  printf 'SIGNATURE_OUTPUT_BEGIN\n'
  grep -nE '^PvNP\.RealizableHardness\.ActualSourceStarLaw\.' "$EV/08_direct_checks.log"
  printf 'SIGNATURE_OUTPUT_END\nAXIOM_DIRECTIVE_COUNT=%s\nAXIOM_OUTPUT_BEGIN\n' "$(grep -cE '^[[:space:]]*#print[[:space:]]+axioms[[:space:]]+' "$CHECKS_SRC")"
  grep -n -A5 -B1 'depends on axioms:' "$EV/08_direct_checks.log" || true
  printf 'AXIOM_OUTPUT_END\nAXIOM_NORMALIZED_BEGIN\n'
  parse_axioms "$EV/08_direct_checks.log" || true
  printf 'AXIOM_NORMALIZED_END\n'
} > "$EV/13_signatures_axioms.log" 2>&1 || finish_failure 61 signatures_axioms
test "$(grep -cE '^[[:space:]]*#check[[:space:]]+' "$CHECKS_SRC")" -eq 11 || finish_failure 62 check_directive_count THEOREM
test "$(grep -cE '^[[:space:]]*#print[[:space:]]+axioms[[:space:]]+' "$CHECKS_SRC")" -eq 1 || finish_failure 63 axiom_directive_count THEOREM
test "$(grep -c 'depends on axioms:' "$EV/08_direct_checks.log")" -eq 1 || finish_failure 64 axiom_report_count THEOREM
parse_axioms "$EV/08_direct_checks.log" >/dev/null 2>&1 || finish_failure 65 unexpected_axiom THEOREM
for name in StarTuple starTuple_card centerLaw_apply extensionLaw_apply starLaw_atom accepts jointIncrementSpan jointlyDirect goodStar acceptanceMass goodStarMass_eq_joint_sum; do
  grep -q "PvNP.RealizableHardness.ActualSourceStarLaw.$name" "$EV/08_direct_checks.log" || finish_failure 66 missing_signature THEOREM
done

{
  if grep -nE '(^|[^[:alnum:]_])(sorry|admit|unsafe|native_decide)([^[:alnum:]_]|$)|^[[:space:]]*axiom[[:space:]]' "$MAIN_SRC" "$CHECKS_SRC"; then
    printf 'SHORTCUT_SCAN=FAIL\n'
    exit 1
  fi
  printf 'SHORTCUT_SCAN=PASS\n'
} > "$EV/14_forbidden_shortcuts.log" 2>&1
shortcut_rc=$?
test "$shortcut_rc" -eq 0 || finish_failure 67 forbidden_shortcut THEOREM

{
  printf 'DIRECT_REPLAY_DIFF_BEGIN\n'
  diff -u "$EV/07_direct_main.log" "$EV/10_replay_main.log"
  diff -u "$EV/08_direct_checks.log" "$EV/11_replay_checks.log"
  printf 'DIRECT_REPLAY_DIFF_END\n'
} > "$EV/15_replay_log_diff.log" 2>&1
diff_rc=$?
test "$diff_rc" -eq 0 || finish_failure 68 unstable_replay_output THEOREM

scan_errors
grep -qE '(^|: )(error:|panic:)|^[^:]+:[0-9]+:[0-9]+: error:' "$EV"/0[7-9]_*.log "$EV"/1[01]_*.log
anchored_rc=$?
test "$anchored_rc" -ne 0 || finish_failure 69 anchored_errors THEOREM
test "$anchored_rc" -eq 1 || finish_failure 70 anchored_error_scan HARNESS

{
  printf 'RESULT=PASS\nCOMMIT=%s\nMAIN_SHA256=%s\nCHECKS_SHA256=%s\nBUNDLE_SHA256=%s\n' "$COMMIT" "$MAIN_SHA" "$CHECKS_SHA" "$BUNDLE_SHA"
  printf 'DEPENDENCY_BUILD_RC=%s\nDIRECT_MAIN_RC=%s\nDIRECT_CHECKS_RC=%s\n' "$dep_rc" "$main_rc" "$checks_rc"
  printf 'COMBINED_RC=%s\nREPLAY_MAIN_RC=%s\nREPLAY_CHECKS_RC=%s\nSHORTCUT_SCAN_RC=%s\n' "$combined_rc" "$replay_main_rc" "$replay_checks_rc" "$shortcut_rc"
  printf 'NETWORK_DENIED=PASS\nOVERLAY_COUNT=2\nCHECK_COUNT=11\nAXIOM_DIRECTIVE_COUNT=1\nAXIOM_REPORT_COUNT=1\nOLEAN_STABILITY=PASS\nREPLAY_LOG_STABILITY=PASS\n'
} > "$EV/OUTCOME.txt"
make_manifest || exit 71
exit 0
