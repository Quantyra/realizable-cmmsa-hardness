import PvNP.RealizableHardness.ActualStarAffineFunctionalSelectionForce
import Mathlib.Algebra.DirectSum.Module
import Mathlib.LinearAlgebra.Dimension.Finite

/-! B50 selector work. This module builds on the green actual-carrier bridge;
it does not claim physical-source transport or full CMMSA certification. -/

namespace PvNP.RealizableHardness.ActualStarAffineFunctionalSelectionForceSelection

open PvNP.RealizableHardness.ActualStarAffineFunctionalSelection

noncomputable section
attribute [local instance] Classical.propDecidable
open scoped DirectSum

/-- Two prescribed functionals on complementary subspaces are realized by
one functional on the ambient finite-dimensional space. The only compatibility
condition is the explicit disjointness of the subspaces. -/
theorem exists_functional_extending_disjoint_pair
    {V : Type*} [AddCommGroup V] [Module (ZMod 2) V] [Finite V]
    (K H : Submodule (ZMod 2) V) (hKH : K ⊓ H = ⊥)
    (g : K →ₗ[ZMod 2] ZMod 2) (ψ : H →ₗ[ZMod 2] ZMod 2) :
    ∃ F : V →ₗ[ZMod 2] ZMod 2,
      F.comp K.subtype = g ∧ F.comp H.subtype = ψ := by
  classical
  let j : K × H →ₗ[ZMod 2] V := K.subtype.coprod H.subtype
  have hdisj : Disjoint (LinearMap.range K.subtype) (LinearMap.range H.subtype) := by
    rw [disjoint_iff]
    simpa only [Submodule.range_subtype] using hKH
  have hker : LinearMap.ker j = ⊥ := by
    rw [show j = K.subtype.coprod H.subtype by rfl,
      LinearMap.ker_coprod_of_disjoint_range _ _ hdisj]
    simp
  have hj : Function.Injective j := LinearMap.ker_eq_bot.mp hker
  let e : (K × H) ≃ₗ[ZMod 2] LinearMap.range j := LinearEquiv.ofInjective j hj
  let label : LinearMap.range j →ₗ[ZMod 2] ZMod 2 :=
    (g.coprod ψ).comp e.symm.toLinearMap
  obtain ⟨F, hF⟩ := LinearMap.exists_extend label
  refine ⟨F, ?_, ?_⟩
  · apply LinearMap.ext
    intro x
    let rx : LinearMap.range j := ⟨j (x, 0), LinearMap.mem_range_self j (x, 0)⟩
    have herx : e.symm rx = (x, 0) := by
      apply e.injective
      apply Subtype.ext
      simp [rx, e, j]
    have hrestr := LinearMap.congr_fun hF rx
    change F ((rx : LinearMap.range j) : V) =
      (g.coprod ψ) (e.symm rx) at hrestr
    have hval : (rx : V) = (x : V) := by
      simp [rx, j]
    rw [hval, herx] at hrestr
    simpa [LinearMap.coprod_apply] using hrestr
  · apply LinearMap.ext
    intro x
    let rx : LinearMap.range j := ⟨j (0, x), LinearMap.mem_range_self j (0, x)⟩
    have herx : e.symm rx = (0, x) := by
      apply e.injective
      apply Subtype.ext
      simp [rx, e, j]
    have hrestr := LinearMap.congr_fun hF rx
    change F ((rx : LinearMap.range j) : V) =
      (g.coprod ψ) (e.symm rx) at hrestr
    have hval : (rx : V) = (x : V) := by
      simp [rx, j]
    rw [hval, herx] at hrestr
    simpa [LinearMap.coprod_apply] using hrestr

end
end PvNP.RealizableHardness.ActualStarAffineFunctionalSelectionForceSelection
