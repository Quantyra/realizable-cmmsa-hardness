#!/usr/bin/env bash
set -u

RUN=gcp_actual_star_followons_a13_20260924T201453Z
HOME_DIR=/home/dfredriksen_quantyra_org
BASE="$HOME_DIR/mz24-fixed-rho-de048da"
IN="$HOME_DIR/${RUN}_incoming"
WT="$HOME_DIR/${RUN}_worktree"
EV="$HOME_DIR/$RUN"
BUNDLE="$IN/accepted-complete-history.bundle"
COMMIT=2db30e6087b4e0546371b4874778e544d4eff4b8
BUNDLE_SHA=19ecf71a496c2d38df80a3b2d62cea47c5833c3a9dfbc1c8ed955a9147b6d271
TOOLCHAIN="$HOME_DIR/.elan/toolchains/leanprover--lean4---v4.34.0-rc2/bin"
LAKE="$TOOLCHAIN/lake"
LEAN="$TOOLCHAIN/lean"
REL=PvNP/RealizableHardness
ACCEPTED="$HOME_DIR/${RUN}_accepted_lean"
DIRECT_WORK="$HOME_DIR/${RUN}_direct_lean"
REPLAY_WORK="$HOME_DIR/${RUN}_replay_lean"
DIRECT="$EV/direct-olean"
REPLAY="$EV/replay-olean"

MODULES=(
  ActualStarLineIncidence
  ActualStarLineIncidenceChecks
  ActualStarKernelSupport
  ActualStarKernelSupportChecks
  ActualStarExtensionProduct
  ActualStarExtensionProductChecks
)
HASHES=(
  14f53ed1450c6d722427a9ce4e8c4fef398084e958ff8d0ac9746c6bcd1cdccf
  450e2301574426612b2ea2c750878ca410788eb2a8dbe3677289bd029eec77fa
  113641bcfa86b2e8582cf612156953a05e29de15bce579ede9e5543b8205f4b7
  f44cf537a438516549ba7f3ba037d7fd1f7cb320134440f420e4ffc89586f33d
  d6ed23a06e1445fd8af0483a34e2a2bc8a5f9857536b704f4d5200d3ba93a131
  83769a72cc2203d8bc258b2a129863eb433e27a6655add4abe10c1b6a09927d4
)
CHECK_COUNTS=(0 1 0 3 0 8)
AXIOM_COUNTS=(0 1 0 1 0 3)

make_manifest() {
  (cd "$EV" && find . -type f ! -name EVIDENCE.sha256 -print0 | sort -z | xargs -0 sha256sum > EVIDENCE.sha256)
}

scan_errors() {
  {
    printf 'ANCHORED_ERRORS_BEGIN\n'
    grep -nE '(^|: )(error([^: ]*)?:|panic:)|^[^:]+:[0-9]+:[0-9]+: error:' "$EV"/*.log 2>/dev/null || true
    printf 'ANCHORED_ERRORS_END\n'
  } > "$EV/90_anchored_errors.log"
}

source_gate() {
  test "$(git -C "$WT" rev-parse HEAD)" = "$COMMIT" || return 1
  test -z "$(git -C "$WT" symbolic-ref -q HEAD)" || return 1
  test "$(git -C "$WT" status --short | wc -l)" -eq 6 || return 1
  for i in "${!MODULES[@]}"; do
    src="lean/$REL/${MODULES[$i]}.lean"
    test "$(sha256sum "$WT/$src" | cut -d' ' -f1)" = "${HASHES[$i]}" || return 1
    git -C "$WT" status --short -- "$src" | grep -q . || return 1
  done
}

parse_axioms() {
  expected="$1"; file="$2"
  awk -v expected="$expected" '
    function trim(s) { sub(/^[[:space:]]+/, "", s); sub(/[[:space:]]+$/, "", s); return s }
    function fail(s) { print "AXIOM_PARSE_ERROR=" s > "/dev/stderr"; bad=1 }
    function validate(  text,n,a,i,t,seen) {
      text=trim(buffer); delete seen
      if (text != "") {
        n=split(text,a,",")
        for (i=1;i<=n;i++) {
          t=trim(a[i])
          if (t != "propext" && t != "Classical.choice" && t != "Quot.sound") fail("unexpected axiom: " t)
          if (seen[t]++) fail("duplicate axiom: " t)
        }
      }
      complete++
      printf "AXIOM_REPORT_%d=[%s]\n", complete, text
    }
    {
      text=$0; marker="depends on axioms:"
      if (!inside) {
        start=index(text,marker); if (!start) next
        reports++; text=substr(text,start+length(marker)); opening=index(text,"[")
        if (!opening) { fail("missing opening bracket"); next }
        text=substr(text,opening+1); buffer=""; inside=1
      } else if (index(text,marker)) fail("nested report")
      closing=index(text,"]")
      if (closing) {
        buffer=buffer " " substr(text,1,closing-1)
        if (trim(substr(text,closing+1)) != "") fail("trailing report text")
        validate(); inside=0
      } else buffer=buffer " " text
    }
    END {
      if (inside) fail("unterminated report")
      if (reports != expected || complete != expected) fail("expected " expected " complete reports, found " complete)
      exit bad
    }
  ' "$file"
}

finish_failure() {
  rc="$1"; stage="$2"; class="${3-HARNESS}"
  test "$rc" -ne 0 || rc=1
  scan_errors
  {
    printf 'RESULT=FAIL\nFAILED_STAGE=%s\nEXIT_CODE=%s\nFAILURE_CLASS=%s\n' "$stage" "$rc" "$class"
    printf 'WORKTREE_HEAD=%s\n' "$(git -C "$WT" rev-parse HEAD 2>/dev/null || printf unavailable)"
  } > "$EV/OUTCOME.txt"
  make_manifest
  exit "$rc"
}

netrun() { sudo -n env "LEAN_PATH=${LEAN_PATH-}" unshare -n -- "$@"; }

test ! -e "$EV" || exit 21
test ! -e "$WT" || exit 22
test ! -e "$ACCEPTED" || exit 23
test ! -e "$DIRECT_WORK" || exit 24
test ! -e "$REPLAY_WORK" || exit 25
mkdir -p "$EV" "$DIRECT/$REL" "$REPLAY/$REL" || exit 26
cp "$IN/driver.sh" "$EV/driver.sh" || finish_failure 27 preserve_driver
cp "$BUNDLE" "$EV/accepted-complete-history.bundle" || finish_failure 28 preserve_bundle

{
  printf 'RUN=%s\nUTC=%s\nEXPECTED_COMMIT=%s\n' "$RUN" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$COMMIT"
  printf 'BASE_HEAD=%s\nTOOLCHAIN_FILE=' "$(git -C "$BASE" rev-parse HEAD)"
  cat "$BASE/lean-toolchain"
  (cd "$BASE" && "$LAKE" --old env lean --version)
  (cd "$BASE" && "$LAKE" --version)
  printf 'NETWORK_NAMESPACE_BEGIN\n'
  sudo -n unshare -n -- sh -c 'printf "NETNS_OK=1\n"; cat /proc/net/route'
  printf 'NETWORK_NAMESPACE_END\nBASE_HASHES_BEGIN\n'
  sha256sum "$BASE/lake-manifest.json" "$BASE/lakefile.toml" "$BASE/lean-toolchain"
  printf 'BASE_HASHES_END\nPACKAGE_REVISIONS_BEGIN\n'
  for package in "$BASE"/.lake/packages/*; do test -e "$package" && printf '%s %s\n' "$(basename "$package")" "$(git -C "$package" rev-parse HEAD)"; done
  printf 'PACKAGE_REVISIONS_END\n'
} > "$EV/01_preflight.log" 2>&1 || finish_failure 29 preflight
grep -q 'Lean (version 4.34.0-rc2' "$EV/01_preflight.log" || finish_failure 30 lean_version

actual_bundle_sha=$(sha256sum "$BUNDLE" | cut -d' ' -f1)
{
  printf 'EXPECTED_BUNDLE_SHA256=%s\nACTUAL_BUNDLE_SHA256=%s\n' "$BUNDLE_SHA" "$actual_bundle_sha"
  git -C "$BASE" bundle verify "$BUNDLE"
} > "$EV/02_bundle_verify.log" 2>&1 || finish_failure 31 bundle_verify
test "$actual_bundle_sha" = "$BUNDLE_SHA" || finish_failure 32 bundle_hash

git clone "$BUNDLE" "$WT" > "$EV/03_checkout_setup.log" 2>&1 || finish_failure 33 clone
{
  git -C "$WT" checkout --detach "$COMMIT"
  mkdir -p "$WT/.lake"
  ln -s "$BASE/.lake/packages" "$WT/.lake/packages"
  ln -s "$BASE/.lake/build" "$WT/.lake/build"
  for module in "${MODULES[@]}"; do cp "$IN/$module.lean" "$WT/lean/$REL/$module.lean"; done
} >> "$EV/03_checkout_setup.log" 2>&1 || finish_failure 34 checkout_overlay

{
  printf 'WORKTREE_HEAD=%s\nWORKTREE_BRANCH=%s\n' "$(git -C "$WT" rev-parse HEAD)" "$(git -C "$WT" symbolic-ref -q --short HEAD || printf DETACHED)"
  printf 'WORKTREE_STATUS_BEGIN\n'; git -C "$WT" status --short; printf 'WORKTREE_STATUS_END\n'
  printf 'OVERLAY_COUNT=6\nOVERLAYS_BEGIN\n'
  for module in "${MODULES[@]}"; do printf 'lean/%s/%s.lean\n' "$REL" "$module"; done
  printf 'OVERLAYS_END\nSOURCE_HASHES_BEGIN\n'
  for module in "${MODULES[@]}"; do sha256sum "$WT/lean/$REL/$module.lean"; done
  sha256sum "$WT/lean-toolchain" "$WT/lakefile.toml" "$WT/lake-manifest.json"
  printf 'SOURCE_HASHES_END\nCACHE_LINKS_BEGIN\n'
  ls -ld "$WT/.lake/packages" "$WT/.lake/build"
  readlink -f "$WT/.lake/packages"; readlink -f "$WT/.lake/build"
  printf 'CACHE_LINKS_END\n'
} > "$EV/04_checkout_metadata.log" 2>&1 || finish_failure 35 checkout_metadata
source_gate || finish_failure 36 source_gate
test "$(readlink -f "$WT/.lake/packages")" = "$BASE/.lake/packages" || finish_failure 37 packages_link
test "$(readlink -f "$WT/.lake/build")" = "$BASE/.lake/build" || finish_failure 38 build_link
for module in "${MODULES[@]}"; do cp "$WT/lean/$REL/$module.lean" "$EV/$module.lean"; done

cd "$WT" || finish_failure 39 worktree_cd
LEAN_PATH_BASE=$("$LAKE" --old env printenv LEAN_PATH) || finish_failure 40 lean_path
source_gate || finish_failure 41 pre_dependency_source_gate
netrun "$LAKE" --old build \
  PvNP.RealizableHardness.ActualSourceStarLaw \
  PvNP.RealizableHardness.GrassmannFlagPosterior \
  PvNP.RealizableHardness.ActualStarJointKernel \
  PvNP.RealizableHardness.ActualStarRelationCount \
  Mathlib.Tactic --force > "$EV/05_dependency_forced_build.log" 2>&1
dep_rc=$?; printf '%s\n' "$dep_rc" > "$EV/05_dependency_forced_build.rc"
test "$dep_rc" -eq 0 || finish_failure 42 dependency_forced_build THEOREM

mkdir -p "$ACCEPTED" || finish_failure 43 accepted_mkdir
cp -a "$WT/.lake/build/lib/lean/." "$ACCEPTED/" || finish_failure 44 accepted_closure_copy
for module in "${MODULES[@]}"; do rm -f "$ACCEPTED/$REL/$module.olean"; done
{
  printf 'LEAN_PATH_BASE=%s\n' "$LEAN_PATH_BASE"
  printf 'ACCEPTED_OLEAN_COUNT=%s\n' "$(find "$ACCEPTED" -type f -name '*.olean' | wc -l)"
  printf 'TARGET_OBJECTS_BEGIN\n'
  for module in "${MODULES[@]}"; do if test -e "$ACCEPTED/$REL/$module.olean"; then printf '%s=PRESENT\n' "$module"; exit 1; else printf '%s=ABSENT\n' "$module"; fi; done
  printf 'TARGET_OBJECTS_END\n'
} > "$EV/06_dependency_closure.log" 2>&1 || finish_failure 45 dependency_closure_metadata

mkdir -p "$DIRECT_WORK" || finish_failure 46 direct_mkdir
cp -a "$ACCEPTED/." "$DIRECT_WORK/" || finish_failure 47 direct_closure_copy
for i in "${!MODULES[@]}"; do
  module="${MODULES[$i]}"; n=$(printf '%02d' $((10 + i)))
  source_gate || finish_failure 48 "pre_direct_${module}_source_gate"
  LEAN_PATH="$DIRECT_WORK:$LEAN_PATH_BASE" netrun "$LEAN" -o "$DIRECT_WORK/$REL/$module.olean" "lean/$REL/$module.lean" > "$EV/${n}_direct_${module}.log" 2>&1
  rc=$?; printf '%s\n' "$rc" > "$EV/${n}_direct_${module}.rc"
  test "$rc" -eq 0 || finish_failure "$rc" "direct_${module}" THEOREM
  cp "$DIRECT_WORK/$REL/$module.olean" "$DIRECT/$REL/" || finish_failure 49 "preserve_direct_${module}"
done

source_gate || finish_failure 50 pre_combined_source_gate
combined_targets=()
for module in "${MODULES[@]}"; do combined_targets+=("PvNP.RealizableHardness.$module"); done
netrun "$LAKE" --old build "${combined_targets[@]}" --force > "$EV/20_combined_forced_build.log" 2>&1
combined_rc=$?; printf '%s\n' "$combined_rc" > "$EV/20_combined_forced_build.rc"
test "$combined_rc" -eq 0 || finish_failure "$combined_rc" combined_forced_build THEOREM

mkdir -p "$REPLAY_WORK" || finish_failure 51 replay_mkdir
cp -a "$ACCEPTED/." "$REPLAY_WORK/" || finish_failure 52 replay_closure_copy
for i in "${!MODULES[@]}"; do
  module="${MODULES[$i]}"; n=$(printf '%02d' $((30 + i)))
  source_gate || finish_failure 53 "pre_replay_${module}_source_gate"
  LEAN_PATH="$REPLAY_WORK:$LEAN_PATH_BASE" netrun "$LEAN" -o "$REPLAY_WORK/$REL/$module.olean" "lean/$REL/$module.lean" > "$EV/${n}_replay_${module}.log" 2>&1
  rc=$?; printf '%s\n' "$rc" > "$EV/${n}_replay_${module}.rc"
  test "$rc" -eq 0 || finish_failure "$rc" "replay_${module}" THEOREM
  cp "$REPLAY_WORK/$REL/$module.olean" "$REPLAY/$REL/" || finish_failure 54 "preserve_replay_${module}"
done

{
  for module in "${MODULES[@]}"; do
    sha256sum "$DIRECT/$REL/$module.olean" "$REPLAY/$REL/$module.olean"
    test "$(sha256sum "$DIRECT/$REL/$module.olean" | cut -d' ' -f1)" = "$(sha256sum "$REPLAY/$REL/$module.olean" | cut -d' ' -f1)" || exit 1
  done
} > "$EV/40_olean_hashes.log" 2>&1 || finish_failure 55 unstable_olean THEOREM

{
  for i in 1 3 5; do
    module="${MODULES[$i]}"; direct_n=$(printf '%02d' $((10 + i)))
    src="lean/$REL/$module.lean"; log="$EV/${direct_n}_direct_${module}.log"
    printf 'MODULE=%s\nCHECK_DIRECTIVES_BEGIN\n' "$module"
    grep -nE '^[[:space:]]*#(check|print[[:space:]]+axioms)[[:space:]]+' "$src"
    printf 'CHECK_DIRECTIVES_END\nSIGNATURE_OUTPUT_BEGIN\n'
    grep -n '^PvNP.RealizableHardness.ActualStar' "$log"
    printf 'SIGNATURE_OUTPUT_END\nAXIOM_NORMALIZED_BEGIN\n'
    parse_axioms "${AXIOM_COUNTS[$i]}" "$log"
    printf 'AXIOM_NORMALIZED_END\n'
  done
} > "$EV/41_signatures_axioms.log" 2>&1 || finish_failure 56 signatures_axioms THEOREM
for i in 1 3 5; do
  module="${MODULES[$i]}"; direct_n=$(printf '%02d' $((10 + i)))
  src="lean/$REL/$module.lean"; log="$EV/${direct_n}_direct_${module}.log"
  test "$(grep -cE '^[[:space:]]*#check[[:space:]]+' "$src")" -eq "${CHECK_COUNTS[$i]}" || finish_failure 57 "check_count_${module}" THEOREM
  test "$(grep -cE '^[[:space:]]*#print[[:space:]]+axioms[[:space:]]+' "$src")" -eq "${AXIOM_COUNTS[$i]}" || finish_failure 58 "axiom_count_${module}" THEOREM
  parse_axioms "${AXIOM_COUNTS[$i]}" "$log" >/dev/null 2>&1 || finish_failure 59 "unexpected_axiom_${module}" THEOREM
  while read -r name; do grep -qF "$name" "$log" || finish_failure 60 "missing_signature_${module}" THEOREM; done < <(awk '/^[[:space:]]*#check[[:space:]]+/ {print $2}' "$src")
done

{
  scan_files=(); for module in "${MODULES[@]}"; do scan_files+=("lean/$REL/$module.lean"); done
  if grep -nE '(^|[^[:alnum:]_])(sorry|admit|unsafe|native_decide)([^[:alnum:]_]|$)|^[[:space:]]*axiom[[:space:]]' "${scan_files[@]}"; then printf 'SHORTCUT_SCAN=FAIL\n'; exit 1; fi
  printf 'SHORTCUT_SCAN=PASS\n'
} > "$EV/42_forbidden_shortcuts.log" 2>&1
shortcut_rc=$?; test "$shortcut_rc" -eq 0 || finish_failure "$shortcut_rc" forbidden_shortcut THEOREM

: > "$EV/43_replay_log_diff.log"
for i in "${!MODULES[@]}"; do
  module="${MODULES[$i]}"; direct_n=$(printf '%02d' $((10 + i))); replay_n=$(printf '%02d' $((30 + i)))
  printf 'DIFF_%s_BEGIN\n' "$module" >> "$EV/43_replay_log_diff.log"
  diff -u "$EV/${direct_n}_direct_${module}.log" "$EV/${replay_n}_replay_${module}.log" >> "$EV/43_replay_log_diff.log" 2>&1
  diff_rc=$?
  printf '%s\n' "$diff_rc" > "$EV/43_replay_log_diff_${module}.rc"
  test "$diff_rc" -eq 0 || finish_failure "$diff_rc" "unstable_replay_output_${module}" THEOREM
  printf 'DIFF_%s_END\n' "$module" >> "$EV/43_replay_log_diff.log"
done

source_gate || finish_failure 61 final_source_gate
scan_errors
grep -qE '(^|: )(error([^: ]*)?:|panic:)|^[^:]+:[0-9]+:[0-9]+: error:' "$EV"/05_*.log "$EV"/1[0-5]_*.log "$EV"/20_*.log "$EV"/3[0-5]_*.log
anchored_rc=$?; printf '%s\n' "$anchored_rc" > "$EV/90_anchored_error_scan.rc"
test "$anchored_rc" -ne 0 || finish_failure 62 anchored_errors THEOREM
test "$anchored_rc" -eq 1 || finish_failure 63 anchored_error_scan HARNESS

{
  printf 'RESULT=PASS\nCOMMIT=%s\nBUNDLE_SHA256=%s\n' "$COMMIT" "$BUNDLE_SHA"
  for i in "${!MODULES[@]}"; do printf '%s_SHA256=%s\n' "${MODULES[$i]}" "${HASHES[$i]}"; done
  printf 'DEPENDENCY_BUILD_RC=%s\nCOMBINED_RC=%s\nSHORTCUT_SCAN_RC=%s\n' "$dep_rc" "$combined_rc" "$shortcut_rc"
  printf 'NETWORK_DENIED=PASS\nOVERLAY_COUNT=6\nAXIOM_ALLOWLIST=PASS\nOLEAN_STABILITY=PASS\nREPLAY_LOG_STABILITY=PASS\nSOURCE_GATE=PASS\n'
} > "$EV/OUTCOME.txt"
make_manifest || exit 64
exit 0
