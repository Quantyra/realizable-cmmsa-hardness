#!/usr/bin/env bash
set -u

RUN=gcp_actual_star_joint_kernel_r8_20260924T170258Z
HOME_DIR=/home/dfredriksen_quantyra_org
BASE="$HOME_DIR/mz24-fixed-rho-de048da"
IN="$HOME_DIR/${RUN}_incoming"
WT="$HOME_DIR/${RUN}_worktree"
EV="$HOME_DIR/$RUN"
BUNDLE="$IN/accepted-complete-history.bundle"
COMMIT=d6e59e2eca47031a31b0795587b4df2cea9540ba
BUNDLE_SHA=e06e0f215f6e0ba7cd398607aedd5ef07076ec68347bfbf899e79fee7e4e2b21
MAIN_SHA=f02b9c19a7145c07eefa78693e24ca4eade747303e75300ebdc54563bd12d40f
CHECKS_SHA=38cd8e0488cae0bb8c5892fce6dba6cb26a6f14bfca8b70c913be595ed42f761
TOOLCHAIN="$HOME_DIR/.elan/toolchains/leanprover--lean4---v4.34.0-rc2/bin"
LAKE="$TOOLCHAIN/lake"
LEAN="$TOOLCHAIN/lean"
MAIN=PvNP.RealizableHardness.ActualStarJointKernel
CHECKS=PvNP.RealizableHardness.ActualStarJointKernelChecks
MAIN_SRC=lean/PvNP/RealizableHardness/ActualStarJointKernel.lean
CHECKS_SRC=lean/PvNP/RealizableHardness/ActualStarJointKernelChecks.lean
REL=PvNP/RealizableHardness
ACCEPTED="$HOME_DIR/${RUN}_accepted_lean"
DIRECT_WORK="$HOME_DIR/${RUN}_direct_lean"
REPLAY_WORK="$HOME_DIR/${RUN}_replay_lean"
DIRECT="$EV/direct-olean"
REPLAY="$EV/replay-olean"

make_manifest() {
  (cd "$EV" && find . -type f ! -name EVIDENCE.sha256 -print0 | sort -z | xargs -0 sha256sum > EVIDENCE.sha256)
}

scan_errors() {
  {
    printf 'ANCHORED_ERRORS_BEGIN\n'
    grep -nE '(^|: )(error([^: ]*)?:|panic:)|^[^:]+:[0-9]+:[0-9]+: error:' "$EV"/*.log 2>/dev/null || true
    printf 'ANCHORED_ERRORS_END\n'
  } > "$EV/16_anchored_errors.log"
}

source_gate() {
  test "$(git -C "$WT" rev-parse HEAD)" = "$COMMIT" &&
  test -z "$(git -C "$WT" symbolic-ref -q HEAD)" &&
  test "$(git -C "$WT" status --short | wc -l)" -eq 2 &&
  test "$(sha256sum "$WT/$MAIN_SRC" | cut -d' ' -f1)" = "$MAIN_SHA" &&
  test "$(sha256sum "$WT/$CHECKS_SRC" | cut -d' ' -f1)" = "$CHECKS_SHA"
}

parse_axioms() {
  awk '
    function trim(s) { sub(/^[[:space:]]+/, "", s); sub(/[[:space:]]+$/, "", s); return s }
    function fail(s) { print "AXIOM_PARSE_ERROR=" s > "/dev/stderr"; bad=1 }
    function validate(  text,n,a,i,t,seen) {
      text=trim(buffer); delete seen
      if (text != "") {
        n=split(text,a,",")
        for (i=1;i<=n;i++) {
          t=trim(a[i])
          if (t != "propext" && t != "Classical.choice" && t != "Quot.sound") fail("unexpected axiom: " t)
          if (seen[t]++) fail("duplicate axiom: " t)
        }
      }
      complete++
      printf "AXIOM_REPORT_%d=[%s]\n", complete, text
    }
    {
      text=$0; marker="depends on axioms:"
      if (!inside) {
        start=index(text,marker); if (!start) next
        reports++; text=substr(text,start+length(marker)); opening=index(text,"[")
        if (!opening) { fail("missing opening bracket"); next }
        text=substr(text,opening+1); buffer=""; inside=1
      } else if (index(text,marker)) fail("nested report")
      closing=index(text,"]")
      if (closing) {
        buffer=buffer " " substr(text,1,closing-1)
        if (trim(substr(text,closing+1)) != "") fail("trailing report text")
        validate(); inside=0
      } else buffer=buffer " " text
    }
    END {
      if (inside) fail("unterminated report")
      if (reports != 2 || complete != 2) fail("expected 2 complete reports, found " complete)
      exit bad
    }
  ' "$1"
}

finish_failure() {
  rc="$1"; stage="$2"; class="${3-HARNESS}"
  scan_errors
  {
    printf 'RESULT=FAIL\nFAILED_STAGE=%s\nEXIT_CODE=%s\nFAILURE_CLASS=%s\n' "$stage" "$rc" "$class"
    printf 'WORKTREE_HEAD=%s\n' "$(git -C "$WT" rev-parse HEAD 2>/dev/null || printf unavailable)"
  } > "$EV/OUTCOME.txt"
  make_manifest
  exit "$rc"
}

netrun() { sudo -n env "LEAN_PATH=${LEAN_PATH-}" unshare -n -- "$@"; }

test ! -e "$EV" || exit 21
test ! -e "$WT" || exit 22
test ! -e "$ACCEPTED" || exit 23
test ! -e "$DIRECT_WORK" || exit 24
test ! -e "$REPLAY_WORK" || exit 25
mkdir -p "$EV" "$DIRECT/$REL" "$REPLAY/$REL" || exit 26
cp "$IN/driver.sh" "$EV/driver.sh" || finish_failure 27 preserve_driver
cp "$BUNDLE" "$EV/accepted-complete-history.bundle" || finish_failure 28 preserve_bundle

{
  printf 'RUN=%s\nUTC=%s\nEXPECTED_COMMIT=%s\n' "$RUN" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$COMMIT"
  printf 'BASE_HEAD=%s\nTOOLCHAIN_FILE=' "$(git -C "$BASE" rev-parse HEAD)"
  cat "$BASE/lean-toolchain"
  (cd "$BASE" && "$LAKE" --old env lean --version)
  (cd "$BASE" && "$LAKE" --version)
  printf 'NETWORK_NAMESPACE_BEGIN\n'
  sudo -n unshare -n -- sh -c 'printf "NETNS_OK=1\n"; cat /proc/net/route'
  printf 'NETWORK_NAMESPACE_END\nBASE_HASHES_BEGIN\n'
  sha256sum "$BASE/lake-manifest.json" "$BASE/lakefile.toml" "$BASE/lean-toolchain"
  printf 'BASE_HASHES_END\nPACKAGE_REVISIONS_BEGIN\n'
  for package in "$BASE"/.lake/packages/*; do test -e "$package" && printf '%s %s\n' "$(basename "$package")" "$(git -C "$package" rev-parse HEAD)"; done
  printf 'PACKAGE_REVISIONS_END\n'
} > "$EV/01_preflight.log" 2>&1 || finish_failure 29 preflight
grep -q 'Lean (version 4.34.0-rc2' "$EV/01_preflight.log" || finish_failure 30 lean_version

actual_bundle_sha=$(sha256sum "$BUNDLE" | cut -d' ' -f1)
{
  printf 'EXPECTED_BUNDLE_SHA256=%s\nACTUAL_BUNDLE_SHA256=%s\n' "$BUNDLE_SHA" "$actual_bundle_sha"
  git -C "$BASE" bundle verify "$BUNDLE"
} > "$EV/02_bundle_verify.log" 2>&1 || finish_failure 31 bundle_verify
test "$actual_bundle_sha" = "$BUNDLE_SHA" || finish_failure 32 bundle_hash

git clone "$BUNDLE" "$WT" > "$EV/03_checkout_setup.log" 2>&1 || finish_failure 33 clone
{
  git -C "$WT" checkout --detach "$COMMIT"
  mkdir -p "$WT/.lake"
  ln -s "$BASE/.lake/packages" "$WT/.lake/packages"
  ln -s "$BASE/.lake/build" "$WT/.lake/build"
  cp "$IN/ActualStarJointKernel.lean" "$WT/$MAIN_SRC"
  cp "$IN/ActualStarJointKernelChecks.lean" "$WT/$CHECKS_SRC"
} >> "$EV/03_checkout_setup.log" 2>&1 || finish_failure 34 checkout_overlay

{
  printf 'WORKTREE_HEAD=%s\nWORKTREE_BRANCH=%s\n' "$(git -C "$WT" rev-parse HEAD)" "$(git -C "$WT" symbolic-ref -q --short HEAD || printf DETACHED)"
  printf 'WORKTREE_STATUS_BEGIN\n'; git -C "$WT" status --short; printf 'WORKTREE_STATUS_END\n'
  printf 'OVERLAY_COUNT=2\nOVERLAYS_BEGIN\n%s\n%s\nOVERLAYS_END\n' "$MAIN_SRC" "$CHECKS_SRC"
  printf 'SOURCE_HASHES_BEGIN\n'; sha256sum "$WT/$MAIN_SRC" "$WT/$CHECKS_SRC" "$WT/lean-toolchain" "$WT/lakefile.toml" "$WT/lake-manifest.json"; printf 'SOURCE_HASHES_END\n'
  printf 'CACHE_LINKS_BEGIN\n'; ls -ld "$WT/.lake/packages" "$WT/.lake/build"; readlink -f "$WT/.lake/packages"; readlink -f "$WT/.lake/build"; printf 'CACHE_LINKS_END\n'
} > "$EV/04_checkout_metadata.log" 2>&1 || finish_failure 35 checkout_metadata
source_gate || finish_failure 36 source_gate
test "$(readlink -f "$WT/.lake/packages")" = "$BASE/.lake/packages" || finish_failure 37 packages_link
test "$(readlink -f "$WT/.lake/build")" = "$BASE/.lake/build" || finish_failure 38 build_link
cp "$WT/$MAIN_SRC" "$EV/ActualStarJointKernel.lean"
cp "$WT/$CHECKS_SRC" "$EV/ActualStarJointKernelChecks.lean"

cd "$WT" || finish_failure 39 worktree_cd
LEAN_PATH_BASE=$("$LAKE" --old env printenv LEAN_PATH) || finish_failure 40 lean_path
source_gate || finish_failure 41 pre_dependency_source_gate
netrun "$LAKE" --old build \
  PvNP.RealizableHardness.ActualSourceStarLaw \
  Mathlib.Algebra.DirectSum.Module \
  Mathlib.LinearAlgebra.Dimension.Constructions \
  Mathlib.LinearAlgebra.FiniteDimensional.Lemmas --force \
  > "$EV/05_dependency_forced_build.log" 2>&1
dep_rc=$?; printf '%s\n' "$dep_rc" > "$EV/05_dependency_forced_build.rc"
test "$dep_rc" -eq 0 || finish_failure 42 dependency_forced_build THEOREM

mkdir -p "$ACCEPTED" || finish_failure 43 accepted_mkdir
cp -a "$WT/.lake/build/lib/lean/." "$ACCEPTED/" || finish_failure 44 accepted_closure_copy
rm -f "$ACCEPTED/$REL/ActualStarJointKernel.olean" "$ACCEPTED/$REL/ActualStarJointKernelChecks.olean"
{
  printf 'LEAN_PATH_BASE=%s\n' "$LEAN_PATH_BASE"
  printf 'ACCEPTED_OLEAN_COUNT=%s\n' "$(find "$ACCEPTED" -type f -name '*.olean' | wc -l)"
  printf 'TARGET_OBJECTS_PRESENT='; if test -e "$ACCEPTED/$REL/ActualStarJointKernel.olean" || test -e "$ACCEPTED/$REL/ActualStarJointKernelChecks.olean"; then printf 'YES\n'; exit 1; else printf 'NO\n'; fi
} > "$EV/06_dependency_closure.log" 2>&1 || finish_failure 45 dependency_closure_metadata

mkdir -p "$DIRECT_WORK" || finish_failure 46 direct_mkdir
cp -a "$ACCEPTED/." "$DIRECT_WORK/" || finish_failure 47 direct_closure_copy
source_gate || finish_failure 48 pre_direct_source_gate
LEAN_PATH="$DIRECT_WORK:$LEAN_PATH_BASE" netrun "$LEAN" -o "$DIRECT_WORK/$REL/ActualStarJointKernel.olean" "$MAIN_SRC" > "$EV/07_direct_main.log" 2>&1
main_rc=$?; printf '%s\n' "$main_rc" > "$EV/07_direct_main.rc"
test "$main_rc" -eq 0 || finish_failure 49 direct_main THEOREM
cp "$DIRECT_WORK/$REL/ActualStarJointKernel.olean" "$DIRECT/$REL/"

source_gate || finish_failure 50 between_direct_source_gate
LEAN_PATH="$DIRECT_WORK:$LEAN_PATH_BASE" netrun "$LEAN" -o "$DIRECT_WORK/$REL/ActualStarJointKernelChecks.olean" "$CHECKS_SRC" > "$EV/08_direct_checks.log" 2>&1
checks_rc=$?; printf '%s\n' "$checks_rc" > "$EV/08_direct_checks.rc"
test "$checks_rc" -eq 0 || finish_failure 51 direct_checks THEOREM
cp "$DIRECT_WORK/$REL/ActualStarJointKernelChecks.olean" "$DIRECT/$REL/"

source_gate || finish_failure 52 pre_combined_source_gate
netrun "$LAKE" --old build "$MAIN" "$CHECKS" --force > "$EV/09_combined_forced_build.log" 2>&1
combined_rc=$?; printf '%s\n' "$combined_rc" > "$EV/09_combined_forced_build.rc"
test "$combined_rc" -eq 0 || finish_failure 53 combined_forced_build THEOREM

mkdir -p "$REPLAY_WORK" || finish_failure 54 replay_mkdir
cp -a "$ACCEPTED/." "$REPLAY_WORK/" || finish_failure 55 replay_closure_copy
source_gate || finish_failure 56 pre_replay_source_gate
LEAN_PATH="$REPLAY_WORK:$LEAN_PATH_BASE" netrun "$LEAN" -o "$REPLAY_WORK/$REL/ActualStarJointKernel.olean" "$MAIN_SRC" > "$EV/10_replay_main.log" 2>&1
replay_main_rc=$?; printf '%s\n' "$replay_main_rc" > "$EV/10_replay_main.rc"
test "$replay_main_rc" -eq 0 || finish_failure 57 replay_main THEOREM
cp "$REPLAY_WORK/$REL/ActualStarJointKernel.olean" "$REPLAY/$REL/"
LEAN_PATH="$REPLAY_WORK:$LEAN_PATH_BASE" netrun "$LEAN" -o "$REPLAY_WORK/$REL/ActualStarJointKernelChecks.olean" "$CHECKS_SRC" > "$EV/11_replay_checks.log" 2>&1
replay_checks_rc=$?; printf '%s\n' "$replay_checks_rc" > "$EV/11_replay_checks.rc"
test "$replay_checks_rc" -eq 0 || finish_failure 58 replay_checks THEOREM
cp "$REPLAY_WORK/$REL/ActualStarJointKernelChecks.olean" "$REPLAY/$REL/"

sha256sum "$DIRECT/$REL/ActualStarJointKernel.olean" "$DIRECT/$REL/ActualStarJointKernelChecks.olean" "$REPLAY/$REL/ActualStarJointKernel.olean" "$REPLAY/$REL/ActualStarJointKernelChecks.olean" > "$EV/12_olean_hashes.log" 2>&1 || finish_failure 59 olean_hashes
test "$(sha256sum "$DIRECT/$REL/ActualStarJointKernel.olean" | cut -d' ' -f1)" = "$(sha256sum "$REPLAY/$REL/ActualStarJointKernel.olean" | cut -d' ' -f1)" || finish_failure 60 unstable_main_olean THEOREM
test "$(sha256sum "$DIRECT/$REL/ActualStarJointKernelChecks.olean" | cut -d' ' -f1)" = "$(sha256sum "$REPLAY/$REL/ActualStarJointKernelChecks.olean" | cut -d' ' -f1)" || finish_failure 61 unstable_checks_olean THEOREM

{
  printf 'CHECK_DIRECTIVES_BEGIN\n'; grep -nE '^[[:space:]]*#(check|print[[:space:]]+axioms)[[:space:]]+' "$CHECKS_SRC"; printf 'CHECK_DIRECTIVES_END\n'
  printf 'SIGNATURE_OUTPUT_BEGIN\n'; grep -n '^PvNP.RealizableHardness.ActualStarJointKernel\.' "$EV/08_direct_checks.log"; printf 'SIGNATURE_OUTPUT_END\n'
  printf 'AXIOM_OUTPUT_BEGIN\n'; grep -n -A5 -B1 'depends on axioms:' "$EV/08_direct_checks.log" || true; printf 'AXIOM_OUTPUT_END\nAXIOM_NORMALIZED_BEGIN\n'
  parse_axioms "$EV/08_direct_checks.log"; printf 'AXIOM_NORMALIZED_END\n'
} > "$EV/13_signatures_axioms.log" 2>&1 || finish_failure 62 signatures_axioms THEOREM
test "$(grep -cE '^[[:space:]]*#check[[:space:]]+' "$CHECKS_SRC")" -eq 6 || finish_failure 63 check_count THEOREM
test "$(grep -cE '^[[:space:]]*#print[[:space:]]+axioms[[:space:]]+' "$CHECKS_SRC")" -eq 2 || finish_failure 64 axiom_directive_count THEOREM
parse_axioms "$EV/08_direct_checks.log" >/dev/null 2>&1 || finish_failure 65 unexpected_axiom THEOREM
for name in incrementFamily incrementSumMap incrementSumMap_range incrementSumMap_domain_finrank jointlyDirect_iff_incrementSumMap_injective not_jointlyDirect_iff_nonzero_incrementKernel; do
  grep -q "PvNP.RealizableHardness.ActualStarJointKernel.$name" "$EV/08_direct_checks.log" || finish_failure 66 missing_signature THEOREM
done

{
  if grep -nE '(^|[^[:alnum:]_])(sorry|admit|unsafe|native_decide)([^[:alnum:]_]|$)|^[[:space:]]*axiom[[:space:]]' "$MAIN_SRC" "$CHECKS_SRC"; then printf 'SHORTCUT_SCAN=FAIL\n'; exit 1; fi
  printf 'SHORTCUT_SCAN=PASS\n'
} > "$EV/14_forbidden_shortcuts.log" 2>&1
shortcut_rc=$?; test "$shortcut_rc" -eq 0 || finish_failure 67 forbidden_shortcut THEOREM

{
  printf 'DIRECT_REPLAY_DIFF_BEGIN\n'; diff -u "$EV/07_direct_main.log" "$EV/10_replay_main.log"; diff -u "$EV/08_direct_checks.log" "$EV/11_replay_checks.log"; printf 'DIRECT_REPLAY_DIFF_END\n'
} > "$EV/15_replay_log_diff.log" 2>&1
diff_rc=$?; test "$diff_rc" -eq 0 || finish_failure 68 unstable_replay_output THEOREM
source_gate || finish_failure 69 final_source_gate
scan_errors
grep -qE '(^|: )(error([^: ]*)?:|panic:)|^[^:]+:[0-9]+:[0-9]+: error:' "$EV"/0[5-9]_*.log "$EV"/1[01]_*.log
anchored_rc=$?; test "$anchored_rc" -ne 0 || finish_failure 70 anchored_errors THEOREM
test "$anchored_rc" -eq 1 || finish_failure 71 anchored_error_scan HARNESS

{
  printf 'RESULT=PASS\nCOMMIT=%s\nMAIN_SHA256=%s\nCHECKS_SHA256=%s\nBUNDLE_SHA256=%s\n' "$COMMIT" "$MAIN_SHA" "$CHECKS_SHA" "$BUNDLE_SHA"
  printf 'DEPENDENCY_BUILD_RC=%s\nDIRECT_MAIN_RC=%s\nDIRECT_CHECKS_RC=%s\nCOMBINED_RC=%s\nREPLAY_MAIN_RC=%s\nREPLAY_CHECKS_RC=%s\nSHORTCUT_SCAN_RC=%s\n' "$dep_rc" "$main_rc" "$checks_rc" "$combined_rc" "$replay_main_rc" "$replay_checks_rc" "$shortcut_rc"
  printf 'NETWORK_DENIED=PASS\nOVERLAY_COUNT=2\nCHECK_COUNT=6\nAXIOM_REPORT_COUNT=2\nAXIOM_ALLOWLIST=PASS\nOLEAN_STABILITY=PASS\nREPLAY_LOG_STABILITY=PASS\nSOURCE_GATE=PASS\n'
} > "$EV/OUTCOME.txt"
make_manifest || exit 72
exit 0
